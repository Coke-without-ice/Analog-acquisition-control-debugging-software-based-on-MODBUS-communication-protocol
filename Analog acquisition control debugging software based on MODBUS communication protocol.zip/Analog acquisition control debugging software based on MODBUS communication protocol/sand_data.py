import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QWidget, QApplication


class Sand_dataWindow(QWidget):
    def __init__(self):
        super(Sand_dataWindow, self).__init__()
        self.ui4 = uic.loadUi("send_data.ui")

class realize_Sand_dataWindow(QWidget):
    def __init__(self):
        super(realize_Sand_dataWindow, self).__init__()
    def action_c(self,data):
        self.subui = Sand_dataWindow()
        self.subui.ui4.show()
        self.subui.ui4.textEdit.setReadOnly(False)
        self.subui.ui4.textEdit.append(data)
        self.subui.ui4.textEdit.setReadOnly(True)
    def action_closeui4(self):
        self.subui = Sand_dataWindow()
        self.subui.ui4.close()
if __name__ == "__main__":
    App = QApplication(sys.argv)
    main_win = Sand_dataWindow()
    main_win.ui4.show()
    sys.exit(App.exec_())