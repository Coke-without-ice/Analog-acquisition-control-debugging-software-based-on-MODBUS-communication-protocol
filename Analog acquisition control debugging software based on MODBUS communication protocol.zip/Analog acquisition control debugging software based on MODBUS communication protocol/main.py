import concurrent.futures
import configparser
import datetime
import logging
import os
import sys
import threading
import time
import re
import crcmod
import numpy as np
import serial
import serial.tools.list_ports
from PyQt5 import uic, QtCore
from PyQt5.QtCore import Qt, pyqtSignal, pyqtSlot
from PyQt5.QtGui import QGuiApplication
from PyQt5.QtWidgets import QApplication, QMessageBox, QFileDialog, QTableWidgetItem
from PyQt5.QtWidgets import QLabel
from pyqtgraph import PlotItem
from pyqtgraph import mkPen
import crcmod.predefined
from scipy.interpolate import interp1d
from sand_data import realize_Sand_dataWindow
from save_file_format import MainWindow
from save_file_format import SubWindow
QGuiApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
QGuiApplication.setAttribute(Qt.AA_UseHighDpiPixmaps)
QGuiApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
# 在程序开始时进行日志配置
# 设置日志记录格式
logging.basicConfig(filename='app.log', level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')


class Stats(QtCore.QObject):
    ser = None  # 初始化ser,用来接受下位机数据
    data = None  # 初始化data,用来存储接收到的数据
    ui = None
    combobox = None
    combobox2 = None
    combobox3 = None
    combobox4 = None
    combobox5 = None
    child_signal = pyqtSignal(str)  # 定义信号

    def __init__(self):
        super().__init__()
        self.portDict = {}
        self.address = ""
        self.Status_code_request = False
        self.Status_code = None
        self.X_text = None
        self.Y_text = None
        self.Z_text = None
        self.H_text = None
        self.C_text = None
        self.M_text = None
        self.start_time = None
        self.Control_time_2 = None
        self.Control_time_1 = None
        self.Serial_port_status = False
        self.instruction = None
        self.threadpool = concurrent.futures.ThreadPoolExecutor(max_workers=6)
        self.row2 = 0
        self.Detection = None
        self.ui4_status = "未打开"
        self.ui = uic.loadUi("window.ui")
        self.combobox = self.ui.comboBox
        self.combobox2 = self.ui.comboBox_2
        self.combobox3 = self.ui.comboBox_3
        self.combobox4 = self.ui.comboBox_4
        self.combobox5 = self.ui.comboBox_5
        self.child_signal.connect(self.handle_child_signal)

        self.last_data_received_time = time.time()
        self.text = ""
        self.text2 = ""
        self.text3 = ""
        self.text4 = ""
        self.text5 = ""
        self.text7 = ""
        self.text8 = ""
        self.text9 = "默认（全局滤波）"
        self.text10 = "默认（全局滤波）"
        self.text11 = "默认（全局滤波）"
        self.text12 = "默认（全局滤波）"
        self.text13 = "默认（全局滤波）"
        self.text14 = "默认（全局滤波）"

        self.timer = None  # 定义计时器
        self.timer2 = None
        self.timer3 = None
        self.timer4 = None
        self.timer5 = None
        self.timer6 = None
        self.timer7 = None

        self.last_sent_data = ""  # 用于保存上一次发送的数据
        self.sent_data2 = ""
        self.data2 = []
        self.Conditions = "数据接受状态"
        self.Alarm_status = "警告程序状态"
        self.choice_1 = "选择1"
        self.choice_2 = "不可以开启滤波"

        self.ui.textEdit_2.append("正在查找串口...")
        self.ScanComPort()
        self.combobox.currentIndexChanged.connect(self.on_combobox_changed)
        self.combobox2.currentIndexChanged.connect(self.on_combobox_2_changed)
        self.combobox3.currentIndexChanged.connect(self.on_combobox_3_changed)
        self.combobox4.currentIndexChanged.connect(self.on_combobox_4_changed)
        self.combobox5.currentIndexChanged.connect(self.on_combobox_5_changed)

        self.ui.pushButton_4.clicked.connect(self.ScanComPort)
        self.ui.pushButton_12.clicked.connect(self.text_change)
        self.ui.pushButton.clicked.connect(self.send_data)
        self.ui.pushButton_5.clicked.connect(self.filter_setting)
        self.ui.pushButton_6.clicked.connect(self.Single_channel_filter_Settings)
        self.ui.pushButton_7.clicked.connect(self.log_display)
        self.ui.pushButton_8.clicked.connect(self.ui7_open)
        self.ui.pushButton_9.clicked.connect(self.action_a)
        self.ui.pushButton_2.clicked.connect(self.sent_data_display)
        self.ui.pushButton_10.clicked.connect(self.action_b)
        self.ui.pushButton_11.clicked.connect(self.save_default_Settings)
        self.ui.pushButton_14.clicked.connect(self.Serial_switch)
        self.ui.pushButton_15.clicked.connect(self.module_switch)
        self.ui.pushButton_3.clicked.connect(self.Empty_window1)
        self.ui.pushButton_28.clicked.connect(self.Empty_window2)
        self.ui.pushButton_20.clicked.connect(self.Acquisition_control)
        self.ui.comboBox_7.currentTextChanged.connect(self.Sampling_time_selection)
        self.ui.pushButton_21.clicked.connect(self.Run_message_clearing)
        self.ui.pushButton_22.clicked.connect(self.Set_display)

        self.ui.textEdit.setPlaceholderText("等待接收并显示模拟量数据")
        self.ui.plainTextEdit.setPlaceholderText("请输入您想发送的模拟量数据")
        self.config = configparser.ConfigParser()
        self.config2 = configparser.ConfigParser()
        self.config3 = configparser.ConfigParser()
        self.config4 = configparser.ConfigParser()
        self.config5 = configparser.ConfigParser()
        self.config6 = configparser.ConfigParser()
        self.config7 = configparser.ConfigParser()
        self.config8 = configparser.ConfigParser()
        self.ui2 = uic.loadUi("image.ui")  # 加载用户界面
        # 初始化串口数据调用
        if os.path.exists('config.ini'):
            self.ui.textEdit_2.append("默认使用保存的串口设置")
            self.use_default_Settings()
            self.combobox.setCurrentText(self.text)
            self.combobox2.setCurrentText(self.text2)
            self.combobox3.setCurrentText(self.text3)
            self.combobox4.setCurrentText(self.text4)
            self.combobox5.setCurrentText(self.text5)
        else:
            print("使用默认初始化")
            self.text = ""
            self.text2 = ""
            self.text3 = ""
            self.text4 = ""
            self.text5 = ""

        if os.path.exists('config5.ini'):
            self.ui.textEdit_2.append("默认使用保存的图像窗口设置")
            self.use_Image_window_editing()
        else:
            self.Window_name1 = "电压/V"
            self.Window_name2 = "电流/A"
            self.Window_name3 = "模块温度/℃"
            self.Window_name4 = "湿度"
            self.Window_name5 = "输入信号"
            self.Window_name6 = "输出信号"

        # 指示灯设置
        self.serial_status_label = QLabel(self.ui)
        self.serial_status_label.setGeometry(QtCore.QRect(234, 6, 20, 20))  # 设置指示灯的位置和大小
        self.serial_status_label.setStyleSheet("background-color: red; border-radius: 10px;")  # 设置指示灯的样式
        self.has_prompted_to_close = False
        # 跨py文件调用函数
        self.sub_ui = MainWindow()
        self.sub_ui3 = SubWindow()
        self.sub_ui2 = realize_Sand_dataWindow()
        self.sub_ui.child_window.child_signal.connect(self.handle_child_signal)  # 连接子窗口的信号
        # 6 通道绘图数据初始化
        self.PosX = 0
        self.data_Index_X = 0  # 数据列表当前索引
        self.data_Index_Y = 0
        self.data_Index_Z = 0
        self.data_Index_H = 0
        self.data_Index_C = 0
        self.data_Index_M = 0
        self.Max_data_X = 0
        self.Max_data_Y = 0
        self.Max_data_Z = 0
        self.Max_data_H = 0
        self.Max_data_C = 0
        self.Max_data_M = 0
        self.min_data_X = 0
        self.min_data_Y = 0
        self.min_data_Z = 0
        self.min_data_H = 0
        self.min_data_C = 0
        self.min_data_M = 0
        # 各数据个数初始化
        self.x_Mean_number = []
        self.y_Mean_number = []
        self.z_Mean_number = []
        self.h_Mean_number = []
        self.c_Mean_number = []
        self.m_Mean_number = []

        self.dataMaxLength = 100  # 数据列表最大长度
        self.dataX = np.zeros(self.dataMaxLength, dtype=float)
        self.dataY = np.zeros(self.dataMaxLength, dtype=float)
        self.dataZ = np.zeros(self.dataMaxLength, dtype=float)
        self.dataH = np.zeros(self.dataMaxLength, dtype=float)
        self.dataC = np.zeros(self.dataMaxLength, dtype=float)
        self.dataM = np.zeros(self.dataMaxLength, dtype=float)
        self.x_data = np.zeros(self.dataMaxLength, dtype=float)
        self.y_data = np.zeros(self.dataMaxLength, dtype=float)
        self.z_data = np.zeros(self.dataMaxLength, dtype=float)
        self.h_data = np.zeros(self.dataMaxLength, dtype=float)
        self.c_data = np.zeros(self.dataMaxLength, dtype=float)
        self.m_data = np.zeros(self.dataMaxLength, dtype=float)

        self.ui2.pushButton.clicked.connect(self.save_png)
        self.ui2.pushButton_2.clicked.connect(self.clear_graphicsView1)
        self.ui2.pushButton_4.clicked.connect(self.clear_graphicsView2)
        self.ui2.pushButton_6.clicked.connect(self.clear_graphicsView3)
        self.ui2.pushButton_8.clicked.connect(self.clear_graphicsView4)
        self.ui2.pushButton_10.clicked.connect(self.clear_graphicsView5)
        self.ui2.pushButton_12.clicked.connect(self.clear_graphicsView6)
        self.ui2.pushButton_14.clicked.connect(self.clear_all_graphicsView)

        self.canvasX = PlotItem()
        self.canvasY = PlotItem()
        self.canvasZ = PlotItem()
        self.canvasH = PlotItem()
        self.canvasC = PlotItem()
        self.canvasM = PlotItem()
        self.canvasX.setLabel('bottom', '时间/s')
        self.canvasX.setLabel('left', f'{self.Window_name1}')
        self.canvasY.setLabel('bottom', '时间/s')
        self.canvasY.setLabel('left', f'{self.Window_name2}')
        self.canvasZ.setLabel('bottom', '时间/s')
        self.canvasZ.setLabel('left', f'{self.Window_name3}')
        self.canvasH.setLabel('bottom', '时间/s')
        self.canvasH.setLabel('left', f'{self.Window_name4}')
        self.canvasC.setLabel('bottom', '时间/s')
        self.canvasC.setLabel('left', f'{self.Window_name5}')
        self.canvasM.setLabel('bottom', '时间/s')
        self.canvasM.setLabel('left', f'{self.Window_name6}')
        self.ui2.graphicsView.setAntialiasing(True)
        self.ui2.graphicsView.setSceneRect(0, 0, 20, 20)
        self.ui2.graphicsView.addItem(self.canvasX)
        self.ui2.graphicsView_2.setSceneRect(0, 0, 20, 20)
        self.ui2.graphicsView_2.addItem(self.canvasY)
        self.ui2.graphicsView_3.setSceneRect(0, 0, 20, 20)
        self.ui2.graphicsView_3.addItem(self.canvasZ)
        self.ui2.graphicsView_4.setSceneRect(0, 0, 20, 20)
        self.ui2.graphicsView_4.addItem(self.canvasH)
        self.ui2.graphicsView_5.setSceneRect(0, 0, 20, 20)
        self.ui2.graphicsView_5.addItem(self.canvasC)
        self.ui2.graphicsView_6.setSceneRect(0, 0, 20, 20)
        self.ui2.graphicsView_6.addItem(self.canvasM)
        # 定义线条的颜色以及使用折线显示
        colors = ['r', 'g', 'b', 'c', 'm', 'purple']  # 定义颜色列表
        self.lineX = self.canvasX.plot(pen=mkPen(color=colors[0], width=2))
        self.lineY = self.canvasY.plot(pen=mkPen(color=colors[1], width=2))
        self.lineZ = self.canvasZ.plot(pen=mkPen(color=colors[2], width=2))
        self.lineH = self.canvasH.plot(pen=mkPen(color=colors[3], width=2))
        self.lineC = self.canvasC.plot(pen=mkPen(color=colors[4], width=2))
        self.lineM = self.canvasM.plot(pen=mkPen(color=colors[5], width=2))
        self.time = datetime.datetime.now()  # 记录初始时间

        self.ui6 = uic.loadUi("image_information.ui")  # 加载用户界面
        self.ui2.pushButton_3.clicked.connect(self.open_ui6)
        self.ui7 = uic.loadUi("Alarm_setting.ui")  # 加载用户界面
        self.ui7.pushButton_6.clicked.connect(self.save_Alarm_setting)

        if os.path.exists('config2.ini'):
            self.ui.textEdit_2.append("默认使用保存的报警设置")
            self.use_default_Alarm_Settings()
            self.ui7.lineEdit.setText(self.max_value1)
            self.ui7.lineEdit_2.setText(self.max_value2)
            self.ui7.lineEdit_3.setText(self.max_value3)
            self.ui7.lineEdit_8.setText(self.max_value4)
            self.ui7.lineEdit_10.setText(self.max_value5)
            self.ui7.lineEdit_12.setText(self.max_value6)
            self.ui7.lineEdit_4.setText(self.min_value1)
            self.ui7.lineEdit_5.setText(self.min_value2)
            self.ui7.lineEdit_6.setText(self.min_value3)
            self.ui7.lineEdit_13.setText(self.min_value4)
            self.ui7.lineEdit_9.setText(self.min_value5)
            self.ui7.lineEdit_11.setText(self.min_value6)
        else:
            self.ui.textEdit_2.append("报警设置默认未启用")
            self.max_value1 = 200
            self.max_value2 = 200
            self.max_value3 = 200
            self.max_value4 = 200
            self.max_value5 = 200
            self.max_value6 = 200
            self.min_value1 = 5
            self.min_value2 = 5
            self.min_value3 = 5
            self.min_value4 = 5
            self.min_value5 = 5
            self.min_value6 = 5
        # 日志记录界面
        self.ui5 = uic.loadUi("DataLog.ui")  # 加载用户界面
        self.current_page = 1
        self.page_size = 10000
        self.ui5.pushButton.clicked.connect(self.prev_page)
        self.ui5.pushButton_2.clicked.connect(self.next_page)
        self.ui5.pushButton_3.clicked.connect(self.log_clear)
        self.current_time()
        # 滤波K值设置
        self.Maximum_value_fluctuation_number = 15
        self.median_filter_number = 3
        self.average_filter_number = 3
        self.De_extreme_number = 3
        self.window_size = 5
        self.alpha = 0.5

        self.ui8 = uic.loadUi("Filter_setting.ui")
        self.ui8.pushButton.clicked.connect(self.get_filter_setting)
        self.ui4 = uic.loadUi("Single_channel_filter_Settings.ui")
        # 设置关闭前处理时间
        self.ui.closeEvent = self.closeEvent  # 将closeEvent方法连接到窗口对象的关闭事件
        self.need_to_save = False  # 用于单一滤波检测选项是否改变
        self.ui4.closeEvent = self.ui4_closeEvent
        self.ui4.pushButton_2.clicked.connect(self.save_default_filter_Settings)
        self.ui4.comboBox_6.currentIndexChanged.connect(self.comboBox_change1)
        self.ui4.comboBox_7.currentIndexChanged.connect(self.comboBox_change2)
        self.ui4.comboBox_8.currentIndexChanged.connect(self.comboBox_change3)
        self.ui4.comboBox_9.currentIndexChanged.connect(self.comboBox_change4)
        self.ui4.comboBox_10.currentIndexChanged.connect(self.comboBox_change5)
        self.ui4.comboBox_11.currentIndexChanged.connect(self.comboBox_change6)

        if os.path.exists('config4.ini'):
            self.ui.textEdit_2.append("默认使用保存的单一滤波设置")
            self.use_default_sole_filter_Settings()
            self.ui4.comboBox_6.setCurrentText(self.text9)
            self.ui4.comboBox_7.setCurrentText(self.text10)
            self.ui4.comboBox_8.setCurrentText(self.text11)
            self.ui4.comboBox_9.setCurrentText(self.text12)
            self.ui4.comboBox_10.setCurrentText(self.text13)
            self.ui4.comboBox_11.setCurrentText(self.text14)
        else:
            print("使用默认初始化")
            self.text9 = "默认（全局滤波）"
            self.text10 = "默认（全局滤波）"
            self.text11 = "默认（全局滤波）"
            self.text12 = "默认（全局滤波）"
            self.text13 = "默认（全局滤波）"
            self.text14 = "默认（全局滤波）"

        self.ui9 = uic.loadUi("logs.ui")
        self.ui.pushButton_13.clicked.connect(self.logs_display)
        self.row = 0
        self.col = 0
        # 初始化数据接受日志状态码
        self.Time_recording = None
        self.Stop_receiving_time = None
        self.ui9.pushButton.clicked.connect(self.Form_clearing)

        self.ui10 = uic.loadUi("edit_instruction.ui")
        self.ui.pushButton_17.clicked.connect(self.edit_instruction_display)
        self.ui10.pushButton.clicked.connect(self.edit_instruction_apply)
        self.ui10.pushButton_2.clicked.connect(self.edit_instruction_save)
        self.ui10.comboBox.currentIndexChanged.connect(self.instruction_comboBox_change)
        self.ui10.pushButton_3.clicked.connect(self.edit_instruction_apply2)
        self.ui10.pushButton_4.clicked.connect(self.edit_instruction_delete)
        self.ui10.pushButton_5.clicked.connect(self.edit_instruction_save_default_Settings)
        self.ui10.checkBox.setChecked(True)
        self.edit_instruction_comboBox_change = None
        self.edit_instruction_default_Settings = None
        self.load_common_instructions()
        if os.path.exists('config3.ini'):
            self.ui.textEdit_2.append("默认使用保存的读取指令")
            self.use_default_instruction_Settings()
            self.ui10.comboBox.setCurrentText(str(self.edit_instruction_default_Settings))
        else:
            self.ui.textEdit_2.append("等待设置读取指令")
        self.ui11 = uic.loadUi("edit_send.ui")
        self.ui.pushButton_19.clicked.connect(self.edit_send_display)
        self.ui11.pushButton_2.clicked.connect(self.edit_send_apply)
        self.ui11.checkBox.stateChanged.connect(self.edit_send_checkBox_change)

        self.ui12 = uic.loadUi("Processing_display.ui")
        self.ui.pushButton_16.clicked.connect(self.Processing_display)
        self.ui12.pushButton.clicked.connect(self.Processing_display_2)
        self.ui13 = uic.loadUi("Set_display.ui")
        self.ui13.pushButton.clicked.connect(self.Set_display_2)

        self.ui14 = uic.loadUi("Image_window_editing.ui")
        self.ui2.pushButton_5.clicked.connect(self.Image_window_editing)
        self.ui14.pushButton.clicked.connect(self.save_Image_window_editing)

        self.ui15 = uic.loadUi("Open_module_instruction.ui")
        self.ui.pushButton_23.clicked.connect(self.Open_module_instruction_ui)
        self.ui15.pushButton.clicked.connect(self.save_module_instruction)
        self.ui15.pushButton_2.clicked.connect(self.use_module_instruction2)
        self.ui15.pushButton_3.clicked.connect(self.save_open_module_instruction)
        self.ui15.pushButton_4.clicked.connect(self.save_close_module_instruction)
        self.load_open_module_instruction()
        self.load_close_module_instruction()
        self.ui15.comboBox.currentTextChanged.connect(self.Instruction_selection1)
        self.ui15.comboBox_2.currentTextChanged.connect(self.Instruction_selection2)
        self.ui15.pushButton_5.clicked.connect(self.open_module_instruction_delete)
        self.ui15.pushButton_6.clicked.connect(self.close_module_instruction_delete)

        if os.path.exists('config6.ini'):
            self.ui.textEdit_2.append("默认使用保存的模块开关指令")
            self.use_module_instruction()
        else:
            self.module_instruction1 = ""
            self.module_instruction2 = ""

        self.ui16 = uic.loadUi("Status_code_editing.ui")
        self.ui.pushButton_18.clicked.connect(self.Status_code_editing)
        self.ui16.pushButton.clicked.connect(self.use_Status_code_editing)

    #   当前时间显示
    def current_time(self):
        self.timer4 = QtCore.QTimer()
        self.timer4.timeout.connect(self.current_time_display)
        self.timer4.start(1000)  # 每1000毫秒读取一次数据

    def current_time_display(self):
        current_time = datetime.datetime.now()  # 记录初始时间
        current_date = current_time.strftime('%Y-%m-%d')  # 格式化日期
        current_time_str = current_time.strftime('%H:%M:%S')  # 格式化时间
        self.ui.label_10.setText(f"当前时间：{current_date} {current_time_str}")

    # 清理数据接受窗口与指令窗口
    def Empty_window1(self):
        self.ui.textEdit.clear()

    def Empty_window2(self):
        self.ui.textEdit_3.clear()

    # 查找可用串口
    def ScanComPort(self):
        self.combobox.clear()
        self.combobox.addItem("")  # 添加空白选项
        portlist = list(serial.tools.list_ports.comports())
        for port in portlist:
            self.portDict["%s" % port[0]] = "%s" % port[1]
            self.combobox.addItem(port[0])
            self.ui.textEdit_2.append(f"发现串口：{port[0]}")
        if len(self.portDict) == 0:
            QMessageBox.critical(self.ui, "警告", "未找到串口设备！", QMessageBox.Cancel, QMessageBox.Cancel)
        pass

    # 添加串口指示灯
    def update_serial_status(self, is_open):
        if is_open:
            self.serial_status_label.setStyleSheet("background-color: green; border-radius: 10px;")
        else:
            self.serial_status_label.setStyleSheet("background-color: red; border-radius: 10px;")

    # 多选按钮选择信号绑定
    def on_combobox_changed(self):
        self.text = self.combobox.currentText()
        print(f"选定的串口为：{self.text}")

    def on_combobox_2_changed(self):
        self.text2 = self.combobox2.currentText()
        print(f"选定的波特率为：{self.text2}")

    def on_combobox_3_changed(self):
        self.text3 = self.combobox3.currentText()
        print(f"选定的数据位为：{self.text3}")

    def on_combobox_4_changed(self):
        self.text4 = self.combobox4.currentText()
        print(f"选定的停止位为：{self.text4}")

    def on_combobox_5_changed(self):
        self.text5 = self.combobox5.currentText()
        print(f"选定的校验位为：{self.text5}")

    # 错误弹出函数
    def show_error_message(self, message):
        QMessageBox.critical(self.ui, "错误", message)

    # 接收到数据展示
    def print_and_display_data(self, data):
        timestamp = time.time()
        date_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
        self.ui.textEdit.append(f"<font color='red'>时间：{date_time}</font>")
        self.ui.textEdit.append(f"接收到的数据：{data}")
        self.ui.textEdit.ensureCursorVisible()
        self.ui.textEdit.repaint()
        self.ui.textEdit.update()

    # 设置保存默认串口配置
    def save_default_Settings(self):
        if not all([self.text.strip(), self.text2.strip(), self.text3.strip(),
                    self.text4.strip(), self.text5.strip()]):
            self.show_error_message("请设置完整的串口参数")
        else:
            self.config['Serial'] = {
                'Port': self.text,
                'Baud_rate': self.text2,
                'Data_bits': self.text3,
                'Stop_bits': self.text4,
                'Parity': self.text5
            }
            self.config.write(open('config.ini', 'w'))
            self.ui.textEdit_2.append("配置已保存")

    # 使用默认串口配置
    def use_default_Settings(self):
        if self.config:
            self.config.read('config.ini')
            self.text = self.config['Serial']['Port']
            self.text2 = self.config['Serial']['Baud_rate']
            self.text3 = self.config['Serial']['Data_bits']
            self.text4 = self.config['Serial']['Stop_bits']
            self.text5 = self.config['Serial']['Parity']
        else:
            print("config.ini不可读")

    # 串口打开函数
    def open_serial_port(self):
        try:
            # 检查串口参数是否完整
            if not all([self.text.strip(), self.text2.strip(), self.text3.strip(),
                        self.text4.strip(), self.text5.strip()]):
                self.show_error_message("请设置完整的串口参数")
                self.ui.pushButton_14.setText('打开串口')
                return

            self.ser = serial.Serial(f"{self.text}", baudrate=int(self.text2 or "0"),
                                     bytesize=int(self.text3 or "0"), stopbits=int(self.text4 or "0"),
                                     parity=self.text5, timeout=5)
            self.Serial_port_status = True
            self.ser.reset_input_buffer()
            if self.ser.is_open:
                print("串口打开成功！")
                self.update_serial_status(True)  # 更新指示灯状态
                self.ui.textEdit_2.append(f"串口打开成功：{self.ser.name}")
            else:
                print("串口打开失败！")
        except Exception as e:
            print(f"串口打开失败: {str(e)}")
            QMessageBox.critical(self.ui, "提示", f"串口无法打开，请检查是否已经被其他应用调用 {str(e)}")
            self.ui.pushButton_14.setText('打开串口')
            logging.exception("发生了错误: %s", str(e))

    # 循环读取函数
    def received_data(self):
        if self.ser is None:
            QMessageBox.critical(self.ui, "错误", "串口未打开！")
        else:
            self.ui.textEdit_2.append("正在接收数据...")
            if self.ser.is_open:
                self.Detection = "正在运行"
                thread8 = threading.Thread(target=self.logs_save())
                thread8.start()
                item = QTableWidgetItem("未保存")
                self.ui9.tableWidget.setItem(self.row2, 1, item)
                item2 = QTableWidgetItem("未保存")
                self.ui9.tableWidget.setItem(self.row2, 2, item2)
                self.ui9.tableWidget.update()
                if self.ui.comboBox_7.currentText() == "默认(持续接收)" or self.ui.comboBox_7.currentText() == "持续接收":
                    self.timer = QtCore.QTimer()
                    self.timer.timeout.connect(self.read_data)
                    self.timer.start(1000)  # 每1000毫秒读取一次数据
                elif self.ui.comboBox_7.currentText() == "自选时间":
                    if self.Control_time_1 is None:
                        print("定时器未启动")
                    else:
                        self.timer7 = QtCore.QTimer()
                        self.timer7.timeout.connect(self.read_data)
                        self.timer7.start(1000)  # 每1000毫秒读取一次数据
                        self.timer7.start()
                        QtCore.QTimer.singleShot(self.Control_time_1, self.text_change)  # 37秒后停止定时器
                else:
                    self.timer7 = QtCore.QTimer()
                    self.timer7.timeout.connect(self.read_data)
                    self.timer7.start(1000)  # 每1000毫秒读取一次数据
                    self.timer7.start()
                    QtCore.QTimer.singleShot(self.Control_time_2, self.text_change)  # 停止定时器
                self.timer2 = QtCore.QTimer()
                self.timer2.timeout.connect(self.image_information)
                self.timer2.start(100)  # 每1000毫秒读取一次数据
                self.start_time = time.time()
                self.timer3 = QtCore.QTimer()
                self.timer3.timeout.connect(self.Alarm_Detection)
                self.timer3.start(100)  # 每1000毫秒读取一次数据
            else:
                self.show_error_message("串口未打开！")
                self.ui.textEdit_2.append("接收数据失败，串口未打开！")

    # 读取函数
    def read_data(self):
        self.send_Read_instruction(self.edit_instruction_default_Settings)
        try:
            self.ser.timeout = 0.01
            # 从串口读取数据
            #   self.ser.flushInput()
            received_data = self.ser.readline()  # 读取数据
            if self.ui.comboBox_8.currentText() == "纯串口通信":
                self.data2 = list(received_data)  # 将接收到的字节数据转换为列表
            elif self.ui.comboBox_8.currentText() == "modbus协议":
                data2 = list(received_data)
                data_len = data2[2]
                data2 = data2[3:-2]
                self.data2 = []
                for i in range(0, data_len, 2):
                    combined_value = (data2[i] << 8) | data2[i + 1]
                    self.data2.append(combined_value)
                data3 = [hex(num) for num in self.data2]
                self.parse_modbus_response(data3)
            if len(self.data2) > 0:
                status_code = self.data2[0]
                if len(self.data2) == 1 and self.Status_code_request is True and status_code == 0:
                    self.ui.textEdit_2.append("状态码为0：执行成功")
                    self.Status_code_request = False
                    self.ui.lineEdit.setText("状态码为0：执行成功")
                elif len(self.data2) == 1 and self.Status_code_request is True:
                    self.ui.textEdit_2.append(f"状态码为{status_code}：执行失败")
                    self.Status_code_request = False
                    self.ui.lineEdit.setText(f"状态码为{status_code}：执行失败")
                # 如果接收到的数据以指定的数据头开头
                self.ui.textEdit_2.append("接收到数据，正在读取...")
                # 处理接收到的数据
                self.print_and_display_data(self.data2)
                # 接收到的数据
                self.last_data_received_time = time.time()  # 更新最后一次接收数据的时间
                self.choice_2 = "可以开启滤波"
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    executor.submit(self.ReceiverPortDatax, self.data2)
                    executor.submit(self.ReceiverPortData_y, self.data2)
                    executor.submit(self.ReceiverPortData_z, self.data2)
                    executor.submit(self.ReceiverPortData_h, self.data2)
                    executor.submit(self.ReceiverPortData_c, self.data2)
                    executor.submit(self.ReceiverPortData_m, self.data2)
                self.Conditions = "数据接收到了"
            else:
                # 没有接收到数据
                self.ui.textEdit_2.append("未收到数据...")
                self.choice_2 = "不可以开启滤波"
                self.Conditions = "数据未接收"
        except Exception as e:
            logging.exception(f"发生了错误: {str(e)}")

    def parse_modbus_response(self, response):
        self.address = int(response[0], 16)
        self.ui.lineEdit_2.setText(f"模块地址为 {self.address}")

    # 数据处理与图像显示函数
    def ReceiverPortDatax(self, data2):
        current_time = datetime.datetime.now()  # 获取当前时间
        time_diff = (current_time - self.time).total_seconds()  # 计算与初始时间的差值，得到时间增量
        float_data = [float(item) for item in data2]
        self.choice_1 = self.ui.comboBox_6.currentText()
        self.ui.label_13.setText("滤波已启用")
        if self.data_Index_X < self.dataMaxLength:
            # 索引自增
            self.x_data = np.arange(self.dataMaxLength) * time_diff / self.dataMaxLength
            self.data_Index_X = self.data_Index_X + 1
        else:
            # 如果self.data_Index_X已经达到或超过了self.dataMaxLength，那么需要进行数据的滚动更新。通过将数据向前移位，并将最新接收到的数据放入最后一个位置。
            self.dataX[:-1] = self.dataX[1:]
            self.dataX[-1] = float(float_data[0])
            self.x_data = np.arange(self.dataMaxLength) * time_diff / self.dataMaxLength
            self.x_data[:-1] = self.x_data[1:]
        self.dataX[self.data_Index_X - 1] = float(float_data[0])
        if self.ui4.comboBox_6.currentText() == "默认（全局滤波）":
            save_operations = {
                ("默认(限幅滤波)", "可以开启滤波"): self.Clipping_filterX,
                ("限幅滤波", "可以开启滤波"): self.Clipping_filterX,
                ("中值滤波", "可以开启滤波"): self.median_filterX,
                ("算术平均滤波", "可以开启滤波"): self.Arithmetic_mean_filteringX,
                ("去极值平均滤波", "可以开启滤波"): self.De_extremal_average_filteringX,
                ("滑动平均滤波", "可以开启滤波"): self.Moving_average_filteringX,
                ("一阶滞后滤波", "可以开启滤波"): self.First_order_lag_filteringX,
            }
            operation = save_operations.get((self.choice_1, self.choice_2))
            if operation:
                operation()
            else:
                print("有None")
        else:
            func_mapping = {
                "限幅滤波": self.Clipping_filterX,
                "中值滤波": self.median_filterX,
                "算术平均滤波": self.Arithmetic_mean_filteringX,
                "去极值平均滤波": self.De_extremal_average_filteringX,
                "滑动平均滤波": self.Moving_average_filteringX,
                "一阶滞后滤波": self.First_order_lag_filteringX,
            }
            # 根据选择执行对应的函数
            selected_option = self.ui4.comboBox_6.currentText()  # 获取comboBox当前选择的选项
            selected_func = func_mapping.get(selected_option)  # 从字典中获取对应的函数
            if selected_func:
                selected_func()  # 执行对应的函数
            else:
                print("未找到对应的函数")
        if self.data_Index_X > 10:
            self.x_Mean_number = self.dataX[self.data_Index_X - 10:self.data_Index_X]  # 将最新接收的数添加到数组中
            self.x_Mean_number = sum(self.x_Mean_number) / len(self.x_Mean_number)  # 计算平均值
        else:
            self.x_Mean_number = sum(self.dataX) / self.data_Index_X
        self.ui2.label_4.setText(f"{self.Window_name1}数据近十项平均值：{self.x_Mean_number}")
        # 更新最大最小值
        self.Max_data_X = max(self.dataX)
        self.min_data_X = min(filter(lambda x: x != 0, self.dataX))
        self.X_text = self.dataX[self.data_Index_X - 1]
        if self.data_Index_X >= 4:
            # 使用插值方法interp1d对数据进行插值，生成平滑的曲线。
            x_interp_func = interp1d(self.x_data[:self.data_Index_X], self.dataX[:self.data_Index_X], kind='cubic')
            # 生成插值后的值，如下
            x_interp = np.linspace(self.x_data[0], self.x_data[self.data_Index_X - 1] - 1e-10, num=100)
            x_interp = np.minimum(x_interp, self.x_data[self.data_Index_X - 1])
            # 更新曲线数据
            self.lineX.setData(x_interp, x_interp_func(x_interp))

    def ReceiverPortData_y(self, data2):
        current_time = datetime.datetime.now()  # 获取当前时间
        time_diff = (current_time - self.time).total_seconds()  # 计算与初始时间的差值，得到时间增量
        float_data = [float(item) for item in data2]
        self.choice_1 = self.ui.comboBox_6.currentText()
        self.ui.label_13.setText("滤波已启用")
        if self.data_Index_Y < self.dataMaxLength:
            # 索引自增
            self.y_data = np.arange(self.dataMaxLength) * time_diff / self.dataMaxLength
            self.data_Index_Y = self.data_Index_Y + 1
        else:
            # 如果self.data_Index_Y已经达到或超过了self.dataMaxLength，那么需要进行数据的滚动更新。通过将数据向前移位，并将最新接收到的数据放入最后一个位置。
            self.dataY[:-1] = self.dataY[1:]
            self.dataY[-1] = float(float_data[1])
            self.y_data = np.arange(self.dataMaxLength) * time_diff / self.dataMaxLength
            self.y_data[:-1] = self.y_data[1:]
        self.dataY[self.data_Index_Y - 1] = float(float_data[1])
        if self.ui4.comboBox_7.currentText() == "默认（全局滤波）":
            save_operations = {
                ("默认(限幅滤波)", "可以开启滤波"): self.Clipping_filterY,
                ("限幅滤波", "可以开启滤波"): self.Clipping_filterY,
                ("中值滤波", "可以开启滤波"): self.median_filterY,
                ("算术平均滤波", "可以开启滤波"): self.Arithmetic_mean_filteringY,
                ("去极值平均滤波", "可以开启滤波"): self.De_extremal_average_filteringY,
                ("滑动平均滤波", "可以开启滤波"): self.Moving_average_filteringY,
                ("一阶滞后滤波", "可以开启滤波"): self.First_order_lag_filteringY,
            }
            operation = save_operations.get((self.choice_1, self.choice_2))
            if operation:
                try:
                    operation()
                except Exception as e:
                    print("滤波失败:", e)
            else:
                print("有None")
        else:
            func_mapping = {
                "限幅滤波": self.Clipping_filterY,
                "中值滤波": self.median_filterY,
                "算术平均滤波": self.Arithmetic_mean_filteringY,
                "去极值平均滤波": self.De_extremal_average_filteringY,
                "滑动平均滤波": self.Moving_average_filteringY,
                "一阶滞后滤波": self.First_order_lag_filteringY,
            }
            # 根据选择执行对应的函数
            selected_option = self.ui4.comboBox_7.currentText()  # 获取comboBox当前选择的选项
            selected_func = func_mapping.get(selected_option)  # 从字典中获取对应的函数
            if selected_func:
                selected_func()  # 执行对应的函数
            else:
                print("未找到对应的函数")
        if self.data_Index_Y > 10:
            self.y_Mean_number = self.dataY[self.data_Index_Y - 10:self.data_Index_Y]  # 将最新接收的数添加到数组中
            self.y_Mean_number = sum(self.y_Mean_number) / len(self.y_Mean_number)  # 计算平均值
        else:
            self.y_Mean_number = sum(self.dataY) / self.data_Index_Y
        self.ui2.label_8.setText(f"{self.Window_name2}数据近十项平均值：{self.y_Mean_number}")
        # 更新最大最小值
        self.Max_data_Y = max(self.dataY)
        self.min_data_Y = min(filter(lambda x: x != 0, self.dataY))
        self.Y_text = self.dataX[self.data_Index_X - 1]
        if self.data_Index_Y >= 4:
            # 使用插值方法interp1d对数据进行插值，生成平滑的曲线。
            y_interp_func = interp1d(self.y_data[:self.data_Index_Y], self.dataY[:self.data_Index_Y], kind='cubic')
            # 生成插值后的值，如下
            y_interp = np.linspace(self.y_data[0], self.y_data[self.data_Index_Y - 1] - 1e-10, num=100)
            y_interp = np.minimum(y_interp, self.y_data[self.data_Index_Y - 1])
            # 更新曲线数据
            self.lineY.setData(y_interp, y_interp_func(y_interp))

    def ReceiverPortData_z(self, data2):
        self.lineZ.setClipToView(True)
        current_time = datetime.datetime.now()  # 获取当前时间
        time_diff = (current_time - self.time).total_seconds()  # 计算与初始时间的差值，得到时间增量
        float_data = [float(item) for item in data2]
        self.choice_1 = self.ui.comboBox_6.currentText()
        self.ui.label_13.setText("滤波已启用")
        if self.data_Index_Z < self.dataMaxLength:
            # 接收到的数据长度小于最大数据缓存长度，直接按索引赋值，索引自增1
            self.dataZ[self.data_Index_Z] = float(float_data[2])
            # 更新接收数据中的最大最小值
            self.z_data = np.arange(self.dataMaxLength) * time_diff / self.dataMaxLength
            # 索引自增
            self.data_Index_Z = self.data_Index_Z + 1
        else:
            # 如果self.data_Index_Z已经达到或超过了self.dataMaxLength，那么需要进行数据的滚动更新。通过将数据向前移位，并将最新接收到的数据放入最后一个位置。
            self.dataZ[:-1] = self.dataZ[1:]
            self.dataZ[-1] = float(float_data[2])
            self.z_data = np.arange(self.dataMaxLength) * time_diff / self.dataMaxLength
            self.z_data[:-1] = self.z_data[1:]
            self.dataZ[self.data_Index_Z - 1] = float(float_data[2])
        if self.ui4.comboBox_8.currentText() == "默认（全局滤波）":
            save_operations = {
                ("默认(限幅滤波)", "可以开启滤波"): self.Clipping_filterZ,
                ("限幅滤波", "可以开启滤波"): self.Clipping_filterZ,
                ("中值滤波", "可以开启滤波"): self.median_filterZ,
                ("算术平均滤波", "可以开启滤波"): self.Arithmetic_mean_filteringZ,
                ("去极值平均滤波", "可以开启滤波"): self.De_extremal_average_filteringZ,
                ("滑动平均滤波", "可以开启滤波"): self.Moving_average_filteringZ,
                ("一阶滞后滤波", "可以开启滤波"): self.First_order_lag_filteringZ,
            }
            operation = save_operations.get((self.choice_1, self.choice_2))
            if operation:
                try:
                    operation()
                except Exception as e:
                    print("滤波失败:", e)
            else:
                print("有None")
        else:
            func_mapping = {
                "限幅滤波": self.Clipping_filterZ,
                "中值滤波": self.median_filterZ,
                "算术平均滤波": self.Arithmetic_mean_filteringZ,
                "去极值平均滤波": self.De_extremal_average_filteringZ,
                "滑动平均滤波": self.Moving_average_filteringZ,
                "一阶滞后滤波": self.First_order_lag_filteringZ,
            }
            # 根据选择执行对应的函数
            selected_option = self.ui4.comboBox_8.currentText()  # 获取comboBox当前选择的选项
            selected_func = func_mapping.get(selected_option)  # 从字典中获取对应的函数
            if selected_func:
                selected_func()  # 执行对应的函数
            else:
                print("未找到对应的函数")
        self.Max_data_Z = max(self.dataZ)
        self.min_data_Z = min(filter(lambda x: x != 0, self.dataZ))
        self.Z_text = self.dataX[self.data_Index_X - 1]
        if self.data_Index_Z > 10:
            self.z_Mean_number = self.dataZ[self.data_Index_Z - 10:self.data_Index_Z]  # 将最新接收的数添加到数组中
            self.z_Mean_number = sum(self.z_Mean_number) / len(self.z_Mean_number)  # 计算平均值
        else:
            self.z_Mean_number = sum(self.dataZ) / self.data_Index_Z
        self.ui2.label_9.setText(f"{self.Window_name3}数据近十项平均值：{self.y_Mean_number}")
        if self.data_Index_Z >= 4:
            # 使用插值方法interp1d对数据进行插值，生成平滑的曲线。
            z_interp_func = interp1d(self.z_data[:self.data_Index_Z], self.dataZ[:self.data_Index_Z], kind='cubic')
            # 生成插值后的值，如下
            z_interp = np.linspace(self.z_data[0], self.z_data[self.data_Index_Z - 1] - 1e-10, num=100)
            z_interp = np.minimum(z_interp, self.z_data[self.data_Index_Z - 1])
            # 更新曲线数据
            self.lineZ.setData(z_interp, z_interp_func(z_interp))

    def ReceiverPortData_h(self, data2):
        self.lineH.setClipToView(True)
        current_time = datetime.datetime.now()  # 获取当前时间
        time_diff = (current_time - self.time).total_seconds()  # 计算与初始时间的差值，得到时间增量
        float_data = [float(item) for item in data2]
        self.choice_1 = self.ui.comboBox_6.currentText()
        self.ui.label_13.setText("滤波已启用")
        if self.data_Index_H < self.dataMaxLength:
            # 接收到的数据长度小于最大数据缓存长度，直接按索引赋值，索引自增1
            self.dataH[self.data_Index_H] = float(float_data[3])
            # 更新接收数据中的最大最小值
            self.h_data = np.arange(self.dataMaxLength) * time_diff / self.dataMaxLength
            # 索引自增
            self.data_Index_H = self.data_Index_H + 1
        else:
            # 如果self.data_Index_H已经达到或超过了self.dataMaxLength，那么需要进行数据的滚动更新。通过将数据向前移位，并将最新接收到的数据放入最后一个位置。
            self.dataH[:-1] = self.dataH[1:]
            self.dataH[-1] = float(float_data[3])
            self.h_data = np.arange(self.dataMaxLength) * time_diff / self.dataMaxLength
            self.h_data[:-1] = self.h_data[1:]
            self.dataH[self.data_Index_H - 1] = float(float_data[3])
        if self.ui4.comboBox_9.currentText() == "默认（全局滤波）":
            save_operations = {
                ("默认(限幅滤波)", "可以开启滤波"): self.Clipping_filterH,
                ("限幅滤波", "可以开启滤波"): self.Clipping_filterH,
                ("中值滤波", "可以开启滤波"): self.median_filterH,
                ("算术平均滤波", "可以开启滤波"): self.Arithmetic_mean_filteringH,
                ("去极值平均滤波", "可以开启滤波"): self.De_extremal_average_filteringH,
                ("滑动平均滤波", "可以开启滤波"): self.Moving_average_filteringH,
                ("一阶滞后滤波", "可以开启滤波"): self.First_order_lag_filteringH,
            }
            operation = save_operations.get((self.choice_1, self.choice_2))
            if operation:
                try:
                    operation()
                except Exception as e:
                    print("滤波失败:", e)
            else:
                print("有None")
        else:
            func_mapping = {
                "限幅滤波": self.Clipping_filterH,
                "中值滤波": self.median_filterH,
                "算术平均滤波": self.Arithmetic_mean_filteringH,
                "去极值平均滤波": self.De_extremal_average_filteringH,
                "滑动平均滤波": self.Moving_average_filteringH,
                "一阶滞后滤波": self.First_order_lag_filteringH,
            }
            # 根据选择执行对应的函数
            selected_option = self.ui4.comboBox_9.currentText()  # 获取comboBox当前选择的选项
            selected_func = func_mapping.get(selected_option)  # 从字典中获取对应的函数
            if selected_func:
                selected_func()  # 执行对应的函数
            else:
                print("未找到对应的函数")
        self.Max_data_H = max(self.dataH)
        self.min_data_H = min(filter(lambda x: x != 0, self.dataH))
        self.H_text = self.dataX[self.data_Index_X - 1]
        if self.data_Index_H > 10:
            self.h_Mean_number = self.dataH[self.data_Index_H - 10:self.data_Index_H]  # 将最新接收的数添加到数组中
            self.h_Mean_number = sum(self.h_Mean_number) / len(self.h_Mean_number)  # 计算平均值
        else:
            self.h_Mean_number = sum(self.dataH) / self.data_Index_H
        self.ui2.label_10.setText(f"{self.Window_name4}数据近十项平均值：{self.h_Mean_number}")
        if self.data_Index_H >= 4:
            h_interp_func = interp1d(self.h_data[:self.data_Index_H], self.dataH[:self.data_Index_H], kind='cubic')
            # 生成插值后的值，如下
            h_interp = np.linspace(self.h_data[0], self.h_data[self.data_Index_H - 1] - 1e-10, num=100)
            h_interp = np.minimum(h_interp, self.h_data[self.data_Index_H - 1])
            # 更新曲线数据
            self.lineH.setData(h_interp, h_interp_func(h_interp))

    def ReceiverPortData_c(self, data2):
        self.lineC.setClipToView(True)
        current_time = datetime.datetime.now()  # 获取当前时间
        time_diff = (current_time - self.time).total_seconds()  # 计算与初始时间的差值，得到时间增量
        float_data = [float(item) for item in data2]
        self.choice_1 = self.ui.comboBox_6.currentText()
        self.ui.label_13.setText("滤波已启用")
        if self.data_Index_C < self.dataMaxLength:
            # 接收到的数据长度小于最大数据缓存长度，直接按索引赋值，索引自增1
            self.dataC[self.data_Index_C] = float(float_data[4])
            # 更新接收数据中的最大最小值
            self.c_data = np.arange(self.dataMaxLength) * time_diff / self.dataMaxLength
            # 索引自增
            self.data_Index_C = self.data_Index_C + 1
        else:
            # 如果self.data_Index_C已经达到或超过了self.dataMaxLength，那么需要进行数据的滚动更新。通过将数据向前移位，并将最新接收到的数据放入最后一个位置。
            self.dataC[:-1] = self.dataC[1:]
            self.dataC[-1] = float(float_data[4])
            self.c_data = np.arange(self.dataMaxLength) * time_diff / self.dataMaxLength
            self.c_data[:-1] = self.c_data[1:]
            self.dataC[self.data_Index_C - 1] = float(float_data[4])
        if self.ui4.comboBox_10.currentText() == "默认（全局滤波）":
            save_operations = {
                ("默认(限幅滤波)", "可以开启滤波"): self.Clipping_filterC,
                ("限幅滤波", "可以开启滤波"): self.Clipping_filterC,
                ("中值滤波", "可以开启滤波"): self.median_filterC,
                ("算术平均滤波", "可以开启滤波"): self.Arithmetic_mean_filteringC,
                ("去极值平均滤波", "可以开启滤波"): self.De_extremal_average_filteringC,
                ("滑动平均滤波", "可以开启滤波"): self.Moving_average_filteringC,
                ("一阶滞后滤波", "可以开启滤波"): self.First_order_lag_filteringC,
            }
            operation = save_operations.get((self.choice_1, self.choice_2))
            if operation:
                try:
                    operation()
                except Exception as e:
                    print("滤波失败:", e)
            else:
                print("有None")
        else:
            func_mapping = {
                "限幅滤波": self.Clipping_filterC,
                "中值滤波": self.median_filterC,
                "算术平均滤波": self.Arithmetic_mean_filteringC,
                "去极值平均滤波": self.De_extremal_average_filteringC,
                "滑动平均滤波": self.Moving_average_filteringC,
                "一阶滞后滤波": self.First_order_lag_filteringC,
            }
            # 根据选择执行对应的函数
            selected_option = self.ui4.comboBox_10.currentText()  # 获取comboBox当前选择的选项
            selected_func = func_mapping.get(selected_option)  # 从字典中获取对应的函数
            if selected_func:
                selected_func()  # 执行对应的函数
            else:
                print("未找到对应的函数")
        self.Max_data_C = max(self.dataC)
        self.min_data_C = min(filter(lambda x: x != 0, self.dataC))
        self.C_text = self.dataX[self.data_Index_X - 1]
        if self.data_Index_C > 10:
            self.c_Mean_number = self.dataC[self.data_Index_C - 10:self.data_Index_C]  # 将最新接收的数添加到数组中
            self.c_Mean_number = sum(self.c_Mean_number) / len(self.c_Mean_number)  # 计算平均值
        else:
            self.c_Mean_number = sum(self.dataC) / self.data_Index_C
        self.ui2.label_11.setText(f"{self.Window_name5}近十项平均值：{self.c_Mean_number}")
        if self.data_Index_C >= 4:
            # 使用插值方法interp1d对数据进行插值，生成平滑的曲线。
            c_interp_func = interp1d(self.c_data[:self.data_Index_C], self.dataC[:self.data_Index_C], kind='cubic')
            # 生成插值后的值，如下
            c_interp = np.linspace(self.c_data[0], self.c_data[self.data_Index_C - 1] - 1e-10, num=100)
            c_interp = np.minimum(c_interp, self.c_data[self.data_Index_C - 1])
            # 更新曲线数据
            self.lineC.setData(c_interp, c_interp_func(c_interp))

    def ReceiverPortData_m(self, data2):
        self.lineM.setClipToView(True)
        current_time = datetime.datetime.now()  # 获取当前时间
        time_diff = (current_time - self.time).total_seconds()  # 计算与初始时间的差值，得到时间增量
        float_data = [float(item) for item in data2]
        self.choice_1 = self.ui.comboBox_6.currentText()
        self.ui.label_13.setText("滤波已启用")
        if self.data_Index_M < self.dataMaxLength:
            # 接收到的数据长度小于最大数据缓存长度，直接按索引赋值，索引自增1
            self.dataM[self.data_Index_M] = float(float_data[5])
            # 更新接收数据中的最大最小值
            self.m_data = np.arange(self.dataMaxLength) * time_diff / self.dataMaxLength
            # 索引自增
            self.data_Index_M = self.data_Index_M + 1
        else:
            # 如果self.data_Index_M已经达到或超过了self.dataMaxLength，那么需要进行数据的滚动更新。通过将数据向前移位，并将最新接收到的数据放入最后一个位置。
            self.dataM[:-1] = self.dataM[1:]
            self.m_data = np.arange(self.dataMaxLength) * time_diff / self.dataMaxLength
            self.m_data[:-1] = self.m_data[1:]
            self.dataM[self.data_Index_M - 1] = float(float_data[5])
        if self.ui4.comboBox_11.currentText() == "默认（全局滤波）":
            save_operations = {
                ("默认(限幅滤波)", "可以开启滤波"): self.Clipping_filterM,
                ("限幅滤波", "可以开启滤波"): self.Clipping_filterM,
                ("中值滤波", "可以开启滤波"): self.median_filterM,
                ("算术平均滤波", "可以开启滤波"): self.Arithmetic_mean_filteringM,
                ("去极值平均滤波", "可以开启滤波"): self.De_extremal_average_filteringM,
                ("滑动平均滤波", "可以开启滤波"): self.Moving_average_filteringM,
                ("一阶滞后滤波", "可以开启滤波"): self.First_order_lag_filteringM,
            }
            operation = save_operations.get((self.choice_1, self.choice_2))
            if operation:
                try:
                    operation()
                except Exception as e:
                    print("滤波失败:", e)
            else:
                print("滤波失败")
        else:
            func_mapping = {
                "限幅滤波": self.Clipping_filterM,
                "中值滤波": self.median_filterM,
                "算术平均滤波": self.Arithmetic_mean_filteringM,
                "去极值平均滤波": self.De_extremal_average_filteringM,
                "滑动平均滤波": self.Moving_average_filteringM,
                "一阶滞后滤波": self.First_order_lag_filteringM,
            }
            # 根据选择执行对应的函数
            selected_option = self.ui4.comboBox_11.currentText()  # 获取comboBox当前选择的选项
            selected_func = func_mapping.get(selected_option)  # 从字典中获取对应的函数
            if selected_func:
                selected_func()  # 执行对应的函数
            else:
                print("未找到对应的函数")
        self.Max_data_M = max(self.dataM)
        self.min_data_M = min(filter(lambda x: x != 0, self.dataM))
        self.M_text = self.dataX[self.data_Index_X - 1]
        if self.data_Index_M > 10:
            self.m_Mean_number = self.dataM[self.data_Index_M - 10:self.data_Index_M]  # 将最新接收的数添加到数组中
            self.m_Mean_number = sum(self.m_Mean_number) / len(self.m_Mean_number)  # 计算平均值
        else:
            self.m_Mean_number = sum(self.dataM) / self.data_Index_M
        self.ui2.label_12.setText(f"{self.Window_name6}近十项平均值：{self.m_Mean_number}")
        if self.data_Index_M >= 4:
            # 使用插值方法interp1d对数据进行插值，生成平滑的曲线。
            m_interp_func = interp1d(self.m_data[:self.data_Index_M], self.dataM[:self.data_Index_M], kind='cubic')
            # 生成插值后的值，如下
            m_interp = np.linspace(self.m_data[0], self.m_data[self.data_Index_M - 1] - 1e-10, num=100)
            m_interp = np.minimum(m_interp, self.m_data[self.data_Index_M - 1])
            # 更新曲线数据
            self.lineM.setData(m_interp, m_interp_func(m_interp))

    def open_ui6(self):
        self.ui6.show()

    # 图像信息分析函数
    def image_information(self):
        elapsed_time = time.time() - self.start_time
        self.ui6.label_4.setText('{:.0f}秒'.format(elapsed_time))
        self.ui6.label_3.setText(str(self.Max_data_X))
        self.ui6.label_9.setText(str(self.Max_data_Y))
        self.ui6.label_15.setText(str(self.Max_data_Z))
        self.ui6.label_21.setText(str(self.Max_data_H))
        self.ui6.label_27.setText(str(self.Max_data_C))
        self.ui6.label_33.setText(str(self.Max_data_M))
        self.ui6.label_6.setText(str(self.min_data_X))
        self.ui6.label_12.setText(str(self.min_data_Y))
        self.ui6.label_18.setText(str(self.min_data_Z))
        self.ui6.label_24.setText(str(self.min_data_H))
        self.ui6.label_30.setText(str(self.min_data_C))
        self.ui6.label_36.setText(str(self.min_data_M))

    # 清除特定窗口图像
    def clear_graphicsView1(self):
        # 清除所有数据
        self.data_Index_X = 0
        self.dataX[:] = 0
        self.x_data[:] = 0
        # 清除已有的线条和画布
        self.canvasX.clear()
        # 断开与旧线条的连接
        self.lineX.clear()
        # 创建新的线条
        self.lineX = self.canvasX.plot(pen=mkPen(color='r', width=2))
        self.ui.textEdit_2.append("已清理电压旧图像，正在绘制新图像...")

    def clear_graphicsView2(self):
        self.data_Index_Y = 0
        self.dataY[:] = 0
        self.x_data[:] = 0
        self.canvasY.clear()
        self.lineY.clear()
        self.lineY = self.canvasY.plot(pen=mkPen(color='g', width=2))
        self.ui.textEdit_2.append("已清理电流旧图像，正在绘制新图像...")

    def clear_graphicsView3(self):
        self.data_Index_Z = 0
        self.dataZ[:] = 0
        self.x_data[:] = 0
        self.canvasZ.clear()
        self.lineZ.clear()
        self.lineZ = self.canvasZ.plot(pen=mkPen(color='b', width=2))
        self.ui.textEdit_2.append("已清理模块温度旧图像，正在绘制新图像...")

    def clear_graphicsView4(self):
        self.data_Index_H = 0
        self.dataH[:] = 0
        self.x_data[:] = 0
        self.canvasH.clear()
        self.lineH.clear()
        self.lineH = self.canvasH.plot(pen=mkPen(color='c', width=2))
        self.ui.textEdit_2.append("已清理湿度旧图像，正在绘制新图像...")

    def clear_graphicsView5(self):
        self.data_Index_C = 0
        self.dataC[:] = 0
        self.x_data[:] = 0
        self.canvasC.clear()
        self.lineC.clear()
        self.lineC = self.canvasC.plot(pen=mkPen(color='m', width=2))
        self.ui.textEdit_2.append("已清理输入信号旧图像，正在绘制新图像...")

    def clear_graphicsView6(self):
        self.data_Index_M = 0
        self.dataM[:] = 0
        self.x_data[:] = 0
        self.canvasM.clear()
        self.lineM.clear()
        self.lineM = self.canvasM.plot(pen=mkPen(color='purple', width=2))
        self.ui.textEdit_2.append("已清理输出信号旧图像，正在绘制新图像...")

    def clear_all_graphicsView(self):
        self.clear_graphicsView1()
        self.clear_graphicsView2()
        self.clear_graphicsView3()
        self.clear_graphicsView4()
        self.clear_graphicsView5()
        self.clear_graphicsView6()
        self.ui.textEdit_2.append("已清理全部旧图像，正在绘制新图像...")

    def stop_ser(self):
        try:
            if self.ser and self.ser.is_open:
                self.ser.reset_input_buffer()
                self.ser.reset_output_buffer()
                self.ser.close()
                self.Serial_port_status = False
                if self.timer is None:
                    pass
                else:
                    self.timer.stop()
                if self.timer2 is None:
                    pass
                else:
                    self.timer2.stop()
                if self.timer3 is None:
                    pass
                else:
                    self.timer3.stop()
                if self.timer5 is None:
                    pass
                else:
                    self.timer5.stop()
                if self.timer6 is None:
                    pass
                else:
                    self.timer6.stop()
                if self.timer7 is None:
                    pass
                else:
                    self.timer7.stop()
                self.ui.textEdit_2.append(f"串口关闭成功：{self.ser.name}")
                self.update_serial_status(False)  # 更新指示灯状态
                self.ui.pushButton_12.setText('开始采集')
            else:
                self.show_error_message("串口已经关闭！请勿再次点击！！！")
            if self.row > self.row2 and self.Detection == "正在运行":
                self.Detection = "停止结束"
                self.logs_save()
                self.row2 += 1
            elif self.Detection == "正在运行":
                self.Detection = "停止结束"
                self.row2 = self.row - 1
                self.logs_save()
        except Exception as e:
            print(f"发生错误：{e}")
            self.show_error_message(f"发生错误：{e}")
            self.update_serial_status(False)  # 更新指示灯状态

    def Stop_collection(self):
        if self.timer is None and self.timer2 is None and self.timer3 is None:
            QMessageBox.question(self.ui, "提示", "未开始数据采集，无需停止！", QMessageBox.Ok)
        else:
            if self.timer is None:
                pass
            else:
                self.timer.stop()
            if self.timer2 is None:
                pass
            else:
                self.timer2.stop()
            if self.timer3 is None:
                pass
            else:
                self.timer3.stop()
            if self.timer5 is None:
                pass
            else:
                self.timer5.stop()
            if self.timer6 is None:
                pass
            else:
                self.timer6.stop()
            if self.timer7 is None:
                pass
            else:
                self.timer7.stop()
            if self.row > self.row2 and self.Detection == "正在运行":
                self.Detection = "停止结束"
                self.logs_save()
                self.row2 += 1
            elif self.Detection == "正在运行":
                self.Detection = "停止结束"
                self.row2 = self.row - 1
                self.logs_save()
            self.ui.textEdit_2.append("数据采集已停止！")

    def edit_instruction_display(self):
        self.ui10.show()

    def edit_instruction_apply(self):
        text = self.ui10.lineEdit.text()
        if text == "":
            QMessageBox.question(self.ui, "提示", "指令不能为空！", QMessageBox.Ok)
        else:
            self.ui.textEdit_2.append("指令已更新为：" + text)
            self.edit_instruction_default_Settings = text
            self.send_Read_instruction(text)

    def edit_instruction_save(self):
        text = self.ui10.lineEdit.text()
        if text == "":
            QMessageBox.question(self.ui, "提示", "指令不能为空！", QMessageBox.Ok)
        else:
            self.ui.textEdit_2.append("指令已保存")
            self.ui10.comboBox.addItem(text)
            with open("common_instructions.txt", "a") as file:
                file.write(text + "\n")

    def load_common_instructions(self):
        if os.path.exists('common_instructions.txt'):
            with open("common_instructions.txt", "r") as file:
                instructions = file.readlines()
            for instruction in instructions:
                self.ui10.comboBox.addItem(instruction.strip())

    def instruction_comboBox_change(self):
        self.instruction = self.ui10.comboBox.currentText()
        self.edit_instruction_comboBox_change = 1

    def edit_instruction_apply2(self):
        if self.edit_instruction_comboBox_change == 1:
            self.send_Read_instruction(self.instruction)
            self.edit_instruction_default_Settings = self.instruction
        elif self.ui10.comboBox.currentText() == "":
            QMessageBox.question(self.ui, "提示", "指令不能为空！", QMessageBox.Ok)
        else:
            self.edit_instruction_default_Settings = self.ui10.comboBox.currentText()
            self.send_Read_instruction(self.ui10.comboBox.currentText())

    def edit_instruction_delete(self):
        index = self.ui10.comboBox.currentIndex()
        self.ui10.comboBox.removeItem(index)
        with open("common_instructions.txt", "w") as f:
            f.write("")
        items = [self.ui10.comboBox.itemText(i) for i in range(self.ui10.comboBox.count())]
        with open('common_instructions.txt', 'w') as f:
            for item in items:
                f.write(item + '\n')
        print("指令已删除。")

    def edit_instruction_save_default_Settings(self):
        if not all([self.ui10.comboBox.currentText()]):
            self.show_error_message("目前无可保存的指令！")
        else:
            self.config3['instruction'] = {
                'instruction2': self.ui10.comboBox.currentText()
            }
            self.config3.write(open('config3.ini', 'w'))
            self.ui.textEdit_2.append("读取指令配置已保存")

    def use_default_instruction_Settings(self):
        if self.config3:
            self.config3.read('config3.ini')
            instruction_str = self.config3['instruction']['instruction2']
            # 将指令字符串转换为整数列表
            cleaned_str = re.sub(r'[^\d]+', ' ', instruction_str)
            temp = [int(num) for num in cleaned_str.split() if num]
            if self.ui10.checkBox.isChecked():
                # 将整数列表转换为字节串
                data_bytes = bytes(temp)
                # 计算CRC并添加到数据末尾
                data_with_crc = self.add_crc(data_bytes)
                # 解析数据信息
                device_address = data_with_crc[0]
                function_code = data_with_crc[1]
                register_values1 = int.from_bytes(data_with_crc[2:4], byteorder='big')
                register_values2 = int.from_bytes(data_with_crc[4:6], byteorder='big')
                CRC_value1 = data_with_crc[6]
                CRC_value2 = data_with_crc[7]
                # 构建结果列表
                result_list = [device_address, function_code, register_values1, register_values2, CRC_value1, CRC_value2]
                self.edit_instruction_default_Settings = result_list
            else:
                device_address = temp[0]
                function_code = temp[1]
                register_values1 = int.from_bytes(temp[2:4], byteorder='big')
                register_values2 = int.from_bytes(temp[4:6], byteorder='big')
                value1 = temp[6]
                value2 = temp[7]
                result_list = [device_address, function_code, register_values1, register_values2, value1, value2]
                self.edit_instruction_default_Settings = result_list
        else:
            print("config.ini不可读")

    def add_crc(self, data_bytes):
        # 计算CRC校验值
        crc16 = crcmod.predefined.Crc('modbus')
        crc16.update(data_bytes)
        crc_value = crc16.crcValue.to_bytes(2, byteorder='little')
        # 添加CRC校验值到数据末尾
        data_with_crc = data_bytes + crc_value
        #   print("添加CRC校验位后的数据：", list(data_with_crc))
        return data_with_crc

    def send_Read_instruction(self, instruction):
        if self.Serial_port_status:
            if isinstance(instruction, str):
                Read_instructions = instruction.split()  # 按空格分割指令字符串
                device_address = int(Read_instructions[0], 16)
                function_code = int(Read_instructions[1], 16)
                start_register_address = int(Read_instructions[2], 16)
                End_register_address = int(Read_instructions[3], 16)
                CRC_value1 = int(Read_instructions[4], 16)
                CRC_value2 = int(Read_instructions[5], 16)
            elif isinstance(instruction, list):
                Read_instructions = instruction
                device_address = int(hex(Read_instructions[0]), 16)
                function_code = int(hex(Read_instructions[1]), 16)
                start_register_address = int(hex(Read_instructions[2]), 16)
                End_register_address = int(hex(Read_instructions[3]), 16)
                CRC_value1 = int(hex(Read_instructions[4]), 16)
                CRC_value2 = int(hex(Read_instructions[5]), 16)
            else:
                print("Error: Unsupported instruction type")
                return
            # 将指令打包成字节串
            Read_instruction = bytes([device_address, function_code,
                                      (start_register_address >> 8) & 0xFF, start_register_address & 0xFF,
                                      (End_register_address >> 8) & 0xFF, End_register_address & 0xFF,
                                      CRC_value1 & 0xFF, CRC_value2 & 0xFF])
            print("发送给串口的数据：", Read_instruction)
            timestamp = time.time()
            date_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
            self.ser.write(Read_instruction)
            self.ui.textEdit_3.append(f"<font color='red'>时间：{date_time}</font> 读取指令：{Read_instruction}")
            self.sent_data2 += str(Read_instruction) + "\n"
        else:
            print("串口未打开")

    def send_data(self):
        if self.ser is None:
            QMessageBox.critical(self.ui, "错误", "串口未打开！")
        else:
            try:
                self.ser.timeout = 0.01
                if not all([self.text.strip(), self.text2.strip(), self.text3.strip(),
                            self.text4.strip(), self.text5.strip()]):
                    self.show_error_message("请设置完整的串口参数")
                    return
                if self.ser.is_open:
                    data_to_send = self.ui.plainTextEdit.toPlainText()
                    if data_to_send == "":
                        pass
                    else:
                        self.sent_data2 += data_to_send + "\n"
                        success_bytes = self.ser.write(data_to_send.encode('utf-8') + b'\r\n')
                        self.ui.textEdit_2.append(f"成功发送字节数: {success_bytes}")
                        # 格式化并设置已发送的数据为只读
                        # 禁用编辑
                        self.disable_editing()
                else:
                    self.show_error_message("串口未打开")
            except Exception as e:
                QMessageBox.critical(self.ui, "错误", f"发送数据失败，请检查串口是否打开: {str(e)}")
                logging.exception("发生了错误: %s", str(e))

    def disable_editing(self):
        self.ui.plainTextEdit.clear()  # 清除文本框中的内容
        self.ui.plainTextEdit.setReadOnly(False)  # 设置为可写

    def sent_data_display(self):
        if not self.sent_data2:
            QMessageBox.critical(self.ui, "错误", "您并未发送过数据")
        else:
            self.sub_ui2.action_c(f"{self.sent_data2}")

    def action_a(self):
        try:
            self.ui.textEdit_2.append("正在查看信号图像！")
            self.ui2.show()  # 显示用户界面
        except Exception as e:
            print(f"发生了错误: {str(e)}")
            logging.exception("发生了错误: %s", str(e))

    def action_b(self):
        text = self.ui.textEdit.toPlainText()
        self.sub_ui.action_b(f"{self.sent_data2}", f"{text}")

    def save_png(self):
        # 以当前时间作为文件名
        current_time = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        # 弹出选择文件夹对话框
        folder_path = QFileDialog.getExistingDirectory(self.ui, "选择保存文件夹", "")
        if folder_path:
            canvas_items = [self.ui2.graphicsView, self.ui2.graphicsView_2, self.ui2.graphicsView_3,
                            self.ui2.graphicsView_4, self.ui2.graphicsView_5, self.ui2.graphicsView_6]
            canvas_names = ['电压显示', '电流显示', '模块温度', '湿度显示', '输入信号', '输出信号']
            # 保存每个图形界面的内容
            for i, canvas in enumerate(canvas_items):
                filename = os.path.join(folder_path, f"{canvas_names[i]}_{current_time}.png")
                # 获取 QGraphicsView 的内容作为图像
                pixmap = canvas.grab()
                # 将图像保存为 PNG 文件
                pixmap.save(filename, "png")
            self.ui.textEdit_2.append(f"图像已保存,地址为 {folder_path}")
            item = QTableWidgetItem(folder_path)
            if self.Detection == "停止结束":
                self.ui9.tableWidget.setItem(self.row2 - 1, 2, item)
            else:
                self.ui9.tableWidget.setItem(self.row2, 2, item)
            self.ui9.tableWidget.update()
            self.ui9.tableWidget.resizeColumnsToContents()
            self.ui9.tableWidget.resizeRowsToContents()
            QMessageBox.question(self.ui, "提示", "已经保存")

    @pyqtSlot(str)
    def handle_child_signal(self, message):
        self.ui.textEdit_2.append("数据已保存,地址为：" + message)
        item = QTableWidgetItem(message)
        if self.Detection == "停止结束":
            self.ui9.tableWidget.setItem(self.row2 - 1, 1, item)
        else:
            self.ui9.tableWidget.setItem(self.row2, 1, item)
        self.ui9.tableWidget.resizeColumnsToContents()
        self.ui9.tableWidget.resizeRowsToContents()

    def closeEvent(self, event):
        reply = QMessageBox.question(self.ui, '提示', '确定要关闭吗？', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            # 执行一些清理操作
            print("软件已打烊")
            self.ui6.close()
            self.ui2.close()
            self.ui7.close()
            if self.ui4_status == "已打开":
                self.ui4.close()
            self.ui5.close()
            self.sub_ui2.action_closeui4()
            self.sub_ui.close_child_window_ui3()
            self.timer4.stop()
            self.ui8.close()
            self.ui9.close()
            self.ui10.close()
            self.ui11.close()
            self.ui12.close()
            self.ui13.close()
            self.ui14.close()
            self.ui15.close()
            self.ui16.close()
            event.accept()
        else:
            event.ignore()

    def ui4_closeEvent(self, event):
        if self.need_to_save:
            reply = QMessageBox.question(self.ui4, '提示', '是否保存设置', QMessageBox.Yes | QMessageBox.No,
                                         QMessageBox.No)
            if reply == QMessageBox.Yes:
                # 执行一些清理操作
                self.save_default_filter_Settings()
                print("配置已保存")
                self.ui4_status = "未打开"
                event.accept()
            elif reply == QMessageBox.No:
                self.use_default_sole_filter_Settings()
                event.accept()
            else:
                event.ignore()

    def save_default_filter_Settings(self):
        self.text9 = self.ui4.comboBox_6.currentText()
        self.ui.textEdit_2.append(f"电压数据滤波方式为{self.text9}")
        self.text10 = self.ui4.comboBox_7.currentText()
        self.ui.textEdit_2.append(f"电流数据滤波方式为{self.text10}")
        self.text11 = self.ui4.comboBox_9.currentText()
        self.ui.textEdit_2.append(f"模块温度数据滤波方式为{self.text11}")
        self.text12 = self.ui4.comboBox_8.currentText()
        self.ui.textEdit_2.append(f"湿度数据滤波方式为{self.text12}")
        self.text13 = self.ui4.comboBox_10.currentText()
        self.ui.textEdit_2.append(f"输入信号滤波方式为{self.text13}")
        self.text14 = self.ui4.comboBox_11.currentText()
        self.ui.textEdit_2.append(f"输出信号滤波方式为{self.text14}")
        self.config4['filter_Settings'] = {
            '电压滤波方式': self.text9,
            '电流滤波方式': self.text10,
            '模块温度滤波方式': self.text11,
            '湿度模块滤波方式': self.text12,
            '输入信号滤波方式': self.text13,
            '输出信号滤波方式': self.text14
        }
        self.config4.write(open('config4.ini', 'w'))
        self.ui.textEdit_2.append("配置已保存")
        self.need_to_save = False

    def use_default_sole_filter_Settings(self):
        self.config4.read('config4.ini')
        if self.config4 and 'filter_Settings' in self.config4:
            self.text9 = self.config4['filter_Settings']['电压滤波方式']
            self.text10 = self.config4['filter_Settings']['电流滤波方式']
            self.text11 = self.config4['filter_Settings']['模块温度滤波方式']
            self.text12 = self.config4['filter_Settings']['湿度模块滤波方式']
            self.text13 = self.config4['filter_Settings']['输入信号滤波方式']
            self.text14 = self.config4['filter_Settings']['输出信号滤波方式']
            self.ui4.comboBox_6.setCurrentText(self.text9)
            self.ui4.comboBox_7.setCurrentText(self.text10)
            self.ui4.comboBox_8.setCurrentText(self.text11)
            self.ui4.comboBox_9.setCurrentText(self.text12)
            self.ui4.comboBox_10.setCurrentText(self.text13)
            self.ui4.comboBox_11.setCurrentText(self.text14)
        else:
            print("config4.ini不可读")

    def comboBox_change1(self):
        self.need_to_save = True

    def comboBox_change2(self):
        self.need_to_save = True

    def comboBox_change3(self):
        self.need_to_save = True

    def comboBox_change4(self):
        self.need_to_save = True

    def comboBox_change5(self):
        self.need_to_save = True

    def comboBox_change6(self):
        self.need_to_save = True

    # 实现开始开始采集与停止采集功能同一个按钮实现
    def text_change(self):
        if self.ui.pushButton_12.text() == '开始采集':
            if self.ser is None:
                QMessageBox.critical(self.ui, "提示", "请先打开串口")
            elif self.ser.is_open:
                self.received_data()
                self.ui.pushButton_12.setText('停止采集')
            else:
                QMessageBox.critical(self.ui, "提示", "请先打开串口")
        elif self.ui.pushButton_12.text() == '停止采集':
            self.Stop_collection()
            self.ui.pushButton_12.setText('开始采集')

    def Serial_switch(self):
        if self.ui.pushButton_14.text() == '打开串口':
            self.ui.pushButton_14.setText('关闭串口')
            self.open_serial_port()
        elif self.ui.pushButton_14.text() == '关闭串口':
            self.stop_ser()
            self.ui.pushButton_14.setText('打开串口')

    def module_switch(self):
        if self.ui.pushButton_15.text() == '开启模块':
            self.Open_module()
            self.ui.pushButton_15.setText('关闭模块')
        elif self.ui.pushButton_15.text() == '关闭模块':
            self.Close_module()
            self.ui.pushButton_15.setText('开启模块')

    def ui7_open(self):
        self.ui7.show()

    def save_Alarm_setting(self):
        self.max_value1 = self.ui7.lineEdit.text()
        self.min_value1 = self.ui7.lineEdit_4.text()
        self.max_value2 = self.ui7.lineEdit_2.text()
        self.min_value2 = self.ui7.lineEdit_5.text()
        self.max_value3 = self.ui7.lineEdit_3.text()
        self.min_value3 = self.ui7.lineEdit_6.text()
        self.max_value4 = self.ui7.lineEdit_8.text()
        self.min_value4 = self.ui7.lineEdit_13.text()
        self.max_value5 = self.ui7.lineEdit_10.text()
        self.min_value5 = self.ui7.lineEdit_9.text()
        self.max_value6 = self.ui7.lineEdit_12.text()
        self.min_value6 = self.ui7.lineEdit_11.text()
        if not all([self.max_value1.strip(), self.max_value2.strip(), self.max_value3.strip(),
                    self.max_value4.strip(), self.max_value5.strip(), self.max_value6.strip(),
                    self.min_value1.strip(), self.min_value2.strip(), self.min_value3.strip(),
                    self.min_value4.strip(), self.min_value5.strip(), self.min_value6.strip()]):
            self.show_error_message("请设置完整的报警参数")
        else:
            self.config2['Alarm_setting'] = {
                'max_value1': self.max_value1,
                'max_value2': self.max_value2,
                'max_value3': self.max_value3,
                'max_value4': self.max_value4,
                'max_value5': self.max_value5,
                'max_value6': self.max_value6,
                'min_value1': self.min_value1,
                'min_value2': self.min_value2,
                'min_value3': self.min_value3,
                'min_value4': self.min_value4,
                'min_value5': self.min_value5,
                'min_value6': self.min_value6
            }
            self.config2.write(open('config2.ini', 'w'))
            self.ui.textEdit_2.append("报警配置已保存")

    #   报警设置使用默认设置
    def use_default_Alarm_Settings(self):
        if self.config2:
            self.config2.read('config2.ini')
            self.max_value1 = self.config2['Alarm_setting']['max_value1']
            self.max_value2 = self.config2['Alarm_setting']['max_value2']
            self.max_value3 = self.config2['Alarm_setting']['max_value3']
            self.max_value4 = self.config2['Alarm_setting']['max_value4']
            self.max_value5 = self.config2['Alarm_setting']['max_value5']
            self.max_value6 = self.config2['Alarm_setting']['max_value6']
            self.min_value1 = self.config2['Alarm_setting']['min_value1']
            self.min_value2 = self.config2['Alarm_setting']['min_value2']
            self.min_value3 = self.config2['Alarm_setting']['min_value3']
            self.min_value4 = self.config2['Alarm_setting']['min_value4']
            self.min_value5 = self.config2['Alarm_setting']['min_value5']
            self.min_value6 = self.config2['Alarm_setting']['min_value6']
        else:
            print("config.ini不可读")

    def Alarm_Detection(self):
        if self.Conditions == "数据接收到了":
            alarms = [
                (self.X_text, self.max_value1, "电压"),
                (self.Y_text, self.max_value2, "电流"),
                (self.Z_text, self.max_value3, "模块温度"),
                (self.H_text, self.max_value4, "湿度"),
                (self.C_text, self.max_value5, "输入信号"),
                (self.M_text, self.max_value6, "输出信号值"),
            ]
            alarms2 = [
                (self.X_text, self.min_value1, "电压"),
                (self.Y_text, self.min_value2, "电流"),
                (self.Z_text, self.min_value3, "模块温度"),
                (self.H_text, self.min_value4, "湿度"),
                (self.C_text, self.min_value5, "输入信号"),
                (self.M_text, self.min_value6, "输出信号值")
            ]
            for data, max_value, name in alarms:
                if data is None:
                    continue
                if self.Alarm_status == "已经存在警告窗口":
                    pass
                elif int(data) > int(max_value) != 0:
                    self.ui.textEdit_2.append(
                        f"<font color='red'>电压{self.dataX[self.data_Index_X - 1]}超过设定最大值{self.max_value1}</font>")
                    self.ui.label_2.setText(f"电压{self.dataX[self.data_Index_X - 1]}超过设定最大值{self.max_value1}")
                    self.ui.label_2.setStyleSheet("color: red;")  # 设置样式表，将文本颜色设为红色
                    self.Alarm_status = "已经存在警告窗口"
                    choice = QMessageBox.question(self.ui, "提示", f"{name}超过设定最大值，是否需要关闭串口！",
                                                  QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                    if choice == QMessageBox.StandardButton.Yes:
                        self.Serial_switch()
                        self.Alarm_status = "警告窗口关闭"
                    else:
                        self.ui.textEdit_2.append("继续接收数据...")
                        self.Alarm_status = "继续检测警告"
                else:
                    self.ui.label_2.setText("警报检测中，未出现问题")
                    self.ui.label_2.setStyleSheet("color: black;")  # 设置样式表，将文本颜色设为红色
            for data2, min_value, name2 in alarms2:
                if data2 is None:
                    continue
                if self.Alarm_status == "已经存在警告窗口":
                    pass
                elif int(data2) < int(min_value) != 0:
                    self.ui.textEdit_2.append(
                        f"<font color='red'>电压{self.dataX[self.data_Index_X - 1]}小于设定最小值{self.min_value1}</font>")
                    self.ui.label_2.setText(f"电压{self.dataX[self.data_Index_X - 1]}小于设定最小值{self.min_value1}")
                    self.ui.label_2.setStyleSheet("color: red;")  # 设置样式表，将文本颜色设为红色
                    self.Alarm_status = "已经存在警告窗口"
                    choice = QMessageBox.question(self.ui, "提示", f"{name2}低于设定最小值，是否需要关闭串口！",
                                                  QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                    if choice == QMessageBox.StandardButton.Yes:
                        self.Serial_switch()
                        self.Alarm_status = "警告窗口关闭"
                    else:
                        self.ui.textEdit_2.append("继续接收数据...")
                        self.Alarm_status = "继续检测警告"
                else:
                    self.ui.label_2.setText("警报检测中，未出现问题")
                    self.ui.label_2.setStyleSheet("color: black;")  # 设置样式表，将文本颜色设为红色

    def log_display(self):
        self.ui5.show()
        with open('app.log', 'r') as f:
            # 定位到指定页的起始位置
            start_pos = (self.current_page - 1) * self.page_size
            f.seek(start_pos)
            # 读取指定数量的数据作为当前页的内容
            log_content = f.read(self.page_size)
        # 将当前页的日志内容设置为TextEdit控件的文本
        self.ui5.textEdit.setText(log_content)
        self.ui5.label.setText(f"当前页数：第{self.current_page}页")

    def prev_page(self):
        if self.current_page > 1:
            self.current_page -= 1
            self.log_display()
            self.ui5.label.setText(f"当前页数：第{self.current_page}页")

    def next_page(self):
        self.current_page += 1
        self.log_display()
        self.ui5.label.setText(f"当前页数：第{self.current_page}页")

    def log_clear(self):
        with open('app.log', 'w') as file:
            file.truncate(0)
        self.ui5.textEdit.setText('')
        self.current_page = 1
        self.ui5.label.setText(f"当前页数：第{self.current_page}页")

    def Single_channel_filter_Settings(self):
        self.ui4.show()
        self.ui4_status = "已打开"
        self.need_to_save = False

    def filter_setting(self):
        self.ui8.show()

    # 保存滤波设置
    def get_filter_setting(self):
        self.Maximum_value_fluctuation_number = self.ui8.lineEdit.text()
        if self.Maximum_value_fluctuation_number == '':
            self.Maximum_value_fluctuation_number = 15
        self.median_filter_number = self.ui8.lineEdit_2.text()
        if self.median_filter_number == '':
            self.median_filter_number = 3
        self.average_filter_number = self.ui8.lineEdit_3.text()
        if self.average_filter_number == '':
            self.average_filter_number = 3
        self.De_extreme_number = self.ui8.lineEdit_4.text()
        if self.De_extreme_number == '':
            self.De_extreme_number = 3
        self.window_size = self.ui8.lineEdit_5.text()
        if self.window_size == '':
            self.window_size = 5
        self.alpha = self.ui8.lineEdit_6.text()
        if self.alpha == '':
            self.alpha = 0.5

    def Clipping_filterX(self):  # 限幅滤波
        if abs(self.dataX[self.data_Index_X] - self.dataX[
                self.data_Index_X - 1]) >= self.Maximum_value_fluctuation_number and self.data_Index_X != 0:
            self.dataX[self.data_Index_X] = self.dataX[self.data_Index_X - 1]

    def Clipping_filterY(self):
        if abs(self.dataY[self.data_Index_Y] - self.dataY[
                self.data_Index_Y - 1]) >= self.Maximum_value_fluctuation_number and self.data_Index_Y != 0:
            self.dataY[self.data_Index_Y] = self.dataY[self.data_Index_Y - 1]

    def Clipping_filterZ(self):
        if abs(self.dataZ[self.data_Index_Z] - self.dataZ[
                self.data_Index_Z - 1]) >= self.Maximum_value_fluctuation_number and self.data_Index_Z != 0:
            self.dataZ[self.data_Index_Z] = self.dataZ[self.data_Index_Z - 1]

    def Clipping_filterH(self):
        if abs(self.dataH[self.data_Index_H] - self.dataH[
                self.data_Index_H - 1]) >= self.Maximum_value_fluctuation_number and self.data_Index_H != 0:
            self.dataH[self.data_Index_H] = self.dataH[self.data_Index_H - 1]

    def Clipping_filterC(self):
        if abs(self.dataC[self.data_Index_C] - self.dataC[
                self.data_Index_C - 1]) >= self.Maximum_value_fluctuation_number and self.data_Index_C != 0:
            self.dataC[self.data_Index_C] = self.dataC[self.data_Index_C - 1]

    def Clipping_filterM(self):
        if abs(self.dataM[self.data_Index_M] - self.dataM[
                self.data_Index_M - 1]) >= self.Maximum_value_fluctuation_number and self.data_Index_M != 0:
            self.dataM[self.data_Index_M] = self.dataM[self.data_Index_M - 1]

    def median_filterX(self):
        if self.data_Index_X >= self.median_filter_number and self.data_Index_X % self.median_filter_number == 0:
            filtered_value = []
            # 获取当前数据窗口
            data_window = self.dataX[self.data_Index_X - self.median_filter_number:self.data_Index_X]
            # 对数据窗口进行排序
            sorted_window = sorted(data_window)
            # 取中间值作为滤波后的值
            median = sorted_window[1]
            filtered_value.extend([median] * self.median_filter_number)
            # 更新数据数组
            self.dataX[self.data_Index_X - self.median_filter_number:self.data_Index_X] = filtered_value[
                                                                                    -self.median_filter_number:]

    def median_filterY(self):
        if self.data_Index_Y >= self.median_filter_number and self.data_Index_Y % self.median_filter_number == 0:
            filtered_value = []
            # 获取当前数据窗口
            data_window = self.dataY[self.data_Index_Y - self.median_filter_number:self.data_Index_Y]
            # 对数据窗口进行排序
            sorted_window = sorted(data_window)
            # 取中间值作为滤波后的值
            median = sorted_window[1]
            filtered_value.extend([median] * self.median_filter_number)
            # 更新数据数组
            self.dataY[self.data_Index_Y - self.median_filter_number:self.data_Index_Y] = filtered_value[
                                                                                    -self.median_filter_number:]

    def median_filterZ(self):
        if self.data_Index_Z >= self.median_filter_number and self.data_Index_Z % self.median_filter_number == 0:
            filtered_value = []
            # 获取当前数据窗口
            data_window = self.dataZ[self.data_Index_Z - self.median_filter_number:self.data_Index_Z]
            # 对数据窗口进行排序
            sorted_window = sorted(data_window)
            # 取中间值作为滤波后的值
            median = sorted_window[1]
            filtered_value.extend([median] * self.median_filter_number)
            # 更新数据数组
            self.dataZ[self.data_Index_Z - self.median_filter_number:self.data_Index_Z] = filtered_value[
                                                                                    -self.median_filter_number:]

    def median_filterH(self):
        if self.data_Index_H >= self.median_filter_number and self.data_Index_H % self.median_filter_number == 0:
            filtered_value = []
            # 获取当前数据窗口
            data_window = self.dataH[self.data_Index_H - self.median_filter_number:self.data_Index_H]
            # 对数据窗口进行排序
            sorted_window = sorted(data_window)
            # 取中间值作为滤波后的值
            median = sorted_window[1]
            filtered_value.extend([median] * self.median_filter_number)
            # 更新数据数组
            self.dataH[self.data_Index_H - self.median_filter_number:self.data_Index_H] = filtered_value[
                                                                                    -self.median_filter_number:]

    def median_filterC(self):
        if self.data_Index_C >= self.median_filter_number and self.data_Index_C % self.median_filter_number == 0:
            filtered_value = []
            # 获取当前数据窗口
            data_window = self.dataC[self.data_Index_C - self.median_filter_number:self.data_Index_C]
            # 对数据窗口进行排序
            sorted_window = sorted(data_window)
            # 取中间值作为滤波后的值
            median = sorted_window[1]
            filtered_value.extend([median] * self.median_filter_number)
            # 更新数据数组
            self.dataC[self.data_Index_C - self.median_filter_number:self.data_Index_C] = filtered_value[
                                                                                    -self.median_filter_number:]

    def median_filterM(self):
        if self.data_Index_M >= self.median_filter_number and self.data_Index_M % self.median_filter_number == 0:
            filtered_value = []
            # 获取当前数据窗口
            data_window = self.dataM[self.data_Index_M - self.median_filter_number:self.data_Index_M]
            # 对数据窗口进行排序
            sorted_window = sorted(data_window)
            # 取中间值作为滤波后的值
            median = sorted_window[1]
            filtered_value.extend([median] * self.median_filter_number)
            # 更新数据数组
            self.dataM[self.data_Index_M - self.median_filter_number:self.data_Index_M] = filtered_value[
                                                                                    -self.median_filter_number:]

    def Arithmetic_mean_filteringX(self):  # 算术平均滤波
        if self.data_Index_X >= self.average_filter_number and self.data_Index_X % self.average_filter_number == 0:
            filtered_data = []
            window_data = self.dataX[self.data_Index_X - self.average_filter_number:self.data_Index_X]
            mean = sum(window_data) / self.average_filter_number
            filtered_data.extend([mean] * self.average_filter_number)
            self.dataX[self.data_Index_X - self.average_filter_number:self.data_Index_X] = filtered_data[
                                                                                     -self.average_filter_number:]

    def Arithmetic_mean_filteringY(self):  # 算术平均滤波
        if self.data_Index_Y >= self.average_filter_number and self.data_Index_Y % self.average_filter_number == 0:
            filtered_data = []
            window_data = self.dataY[self.data_Index_Y - self.average_filter_number:self.data_Index_Y]
            mean = sum(window_data) / self.average_filter_number
            filtered_data.extend([mean] * self.average_filter_number)
            self.dataY[self.data_Index_Y - self.average_filter_number:self.data_Index_Y] = filtered_data[
                                                                                     -self.average_filter_number:]

    def Arithmetic_mean_filteringZ(self):  # 算术平均滤波
        if self.data_Index_Z >= self.average_filter_number and self.data_Index_Z % self.average_filter_number == 0:
            filtered_data = []
            window_data = self.dataZ[self.data_Index_Z - self.average_filter_number:self.data_Index_Z]
            mean = sum(window_data) / self.average_filter_number
            filtered_data.extend([mean] * self.average_filter_number)
            self.dataZ[self.data_Index_Z - self.average_filter_number:self.data_Index_Z] = filtered_data[
                                                                                     -self.average_filter_number:]

    def Arithmetic_mean_filteringH(self):  # 算术平均滤波
        if self.data_Index_H >= self.average_filter_number and self.data_Index_H % self.average_filter_number == 0:
            filtered_data = []
            window_data = self.dataH[self.data_Index_H - self.average_filter_number:self.data_Index_H]
            mean = sum(window_data) / self.average_filter_number
            filtered_data.extend([mean] * self.average_filter_number)
            self.dataH[self.data_Index_H - self.average_filter_number:self.data_Index_H] = filtered_data[
                                                                                     -self.average_filter_number:]

    def Arithmetic_mean_filteringC(self):  # 算术平均滤波
        if self.data_Index_C >= self.average_filter_number and self.data_Index_C % self.average_filter_number == 0:
            filtered_data = []
            window_data = self.dataC[self.data_Index_C - self.average_filter_number:self.data_Index_C]
            mean = sum(window_data) / self.average_filter_number
            filtered_data.extend([mean] * self.average_filter_number)
            self.dataC[self.data_Index_C - self.average_filter_number:self.data_Index_C] = filtered_data[
                                                                                     -self.average_filter_number:]

    def Arithmetic_mean_filteringM(self):  # 算术平均滤波
        if self.data_Index_M >= self.average_filter_number and self.data_Index_M % self.average_filter_number == 0:
            filtered_data = []
            window_data = self.dataM[self.data_Index_M - self.average_filter_number:self.data_Index_M]
            mean = sum(window_data) / self.average_filter_number
            filtered_data.extend([mean] * self.average_filter_number)
            self.dataM[self.data_Index_M - self.average_filter_number:self.data_Index_M] = filtered_data[
                                                                                     -self.average_filter_number:]

    def De_extremal_average_filteringX(self):  # 去极值平均滤波
        if self.data_Index_X >= self.De_extreme_number and self.data_Index_X % self.De_extreme_number == 0:
            filtered_data = []
            data = self.dataX[self.data_Index_X - self.De_extreme_number:self.data_Index_X]
            sorted_window = sorted(data)
            median = sorted_window[0:self.De_extreme_number - 1]
            mean = sum(median) / (self.De_extreme_number - 1)
            filtered_data.extend([mean] * self.De_extreme_number)
            print(filtered_data)
            self.dataX[self.data_Index_X - self.De_extreme_number:self.data_Index_X] = filtered_data[
                                                                                       -self.De_extreme_number:]

    def De_extremal_average_filteringY(self):  # 去极值平均滤波
        if self.data_Index_Y >= self.De_extreme_number and self.data_Index_Y % self.De_extreme_number == 0:
            filtered_data = []
            data = self.dataY[self.data_Index_Y - self.De_extreme_number:self.data_Index_Y]
            sorted_window = sorted(data)
            median = sorted_window[0:self.De_extreme_number - 1]
            mean = sum(median) / (self.De_extreme_number - 1)
            filtered_data.extend([mean] * self.De_extreme_number)
            print(filtered_data)
            self.dataY[self.data_Index_Y - self.De_extreme_number:self.data_Index_Y] = filtered_data[
                                                                                       -self.De_extreme_number:]

    def De_extremal_average_filteringZ(self):  # 去极值平均滤波
        if self.data_Index_Z >= self.De_extreme_number and self.data_Index_Z % self.De_extreme_number == 0:
            filtered_data = []
            data = self.dataZ[self.data_Index_Z - self.De_extreme_number:self.data_Index_Z]
            sorted_window = sorted(data)
            median = sorted_window[0:self.De_extreme_number - 1]
            mean = sum(median) / (self.De_extreme_number - 1)
            filtered_data.extend([mean] * self.De_extreme_number)
            print(filtered_data)
            self.dataZ[self.data_Index_Z - self.De_extreme_number:self.data_Index_Z] = filtered_data[
                                                                                       -self.De_extreme_number:]

    def De_extremal_average_filteringH(self):  # 去极值平均滤波
        if self.data_Index_H >= self.De_extreme_number and self.data_Index_H % self.De_extreme_number == 0:
            filtered_data = []
            data = self.dataH[self.data_Index_H - self.De_extreme_number:self.data_Index_H]
            sorted_window = sorted(data)
            median = sorted_window[0:self.De_extreme_number - 1]
            mean = sum(median) / (self.De_extreme_number - 1)
            filtered_data.extend([mean] * self.De_extreme_number)
            print(filtered_data)
            self.dataH[self.data_Index_H - self.De_extreme_number:self.data_Index_H] = filtered_data[
                                                                                       -self.De_extreme_number:]

    def De_extremal_average_filteringC(self):  # 去极值平均滤波
        if self.data_Index_C >= self.De_extreme_number and self.data_Index_C % self.De_extreme_number == 0:
            filtered_data = []
            data = self.dataC[self.data_Index_C - self.De_extreme_number:self.data_Index_C]
            sorted_window = sorted(data)
            median = sorted_window[0:self.De_extreme_number - 1]
            mean = sum(median) / (self.De_extreme_number - 1)
            filtered_data.extend([mean] * self.De_extreme_number)
            print(filtered_data)
            self.dataC[self.data_Index_C - self.De_extreme_number:self.data_Index_C] = filtered_data[
                                                                                       -self.De_extreme_number:]

    def De_extremal_average_filteringM(self):  # 去极值平均滤波
        if self.data_Index_M >= self.De_extreme_number and self.data_Index_M % self.De_extreme_number == 0:
            filtered_data = []
            data = self.dataM[self.data_Index_M - self.De_extreme_number:self.data_Index_M]
            sorted_window = sorted(data)
            median = sorted_window[0:self.De_extreme_number - 1]
            mean = sum(median) / (self.De_extreme_number - 1)
            filtered_data.extend([mean] * self.De_extreme_number)
            print(filtered_data)
            self.dataM[self.data_Index_M - self.De_extreme_number:self.data_Index_M] = filtered_data[
                                                                                       -self.De_extreme_number:]

    def Moving_average_filteringX(self):  # 滑动平均滤波
        if self.data_Index_X < self.window_size:
            return
        data = self.dataX[self.data_Index_X - self.window_size:self.data_Index_X]
        mean = sum(data) / self.window_size
        print("mean:", mean)
        self.dataX[self.data_Index_X - 1] = mean

    def Moving_average_filteringY(self):  # 滑动平均滤波
        if self.data_Index_Y < self.window_size:
            return
        data = self.dataY[self.data_Index_Y - self.window_size:self.data_Index_Y]
        mean = sum(data) / self.window_size
        print("mean:", mean)
        self.dataY[self.data_Index_Y - 1] = mean

    def Moving_average_filteringZ(self):  # 滑动平均滤波
        if self.data_Index_Z < self.window_size:
            return
        data = self.dataZ[self.data_Index_Z - self.window_size:self.data_Index_Z]
        mean = sum(data) / self.window_size
        print("mean:", mean)
        self.dataZ[self.data_Index_Z - 1] = mean

    def Moving_average_filteringH(self):  # 滑动平均滤波
        if self.data_Index_H < self.window_size:
            return
        data = self.dataH[self.data_Index_H - self.window_size:self.data_Index_H]
        mean = sum(data) / self.window_size
        print("mean:", mean)
        self.dataH[self.data_Index_H - 1] = mean

    def Moving_average_filteringC(self):  # 滑动平均滤波
        if self.data_Index_C < self.window_size:
            return
        data = self.dataC[self.data_Index_C - self.window_size:self.data_Index_C]
        mean = sum(data) / self.window_size
        print("mean:", mean)
        self.dataC[self.data_Index_C - 1] = mean

    def Moving_average_filteringM(self):  # 滑动平均滤波
        if self.data_Index_M < self.window_size:
            return
        data = self.dataM[self.data_Index_M - self.window_size:self.data_Index_M]
        mean = sum(data) / self.window_size
        print("mean:", mean)
        self.dataM[self.data_Index_M - 1] = mean

    def First_order_lag_filteringX(self):  # 一阶滞后滤波
        self.alpha = 0.5  # 设置滞后系数
        if self.data_Index_X > 0:
            self.dataX[self.data_Index_X] = self.alpha * self.dataX[self.data_Index_X] + (1 - self.alpha) * self.dataX[
                self.data_Index_X - 1]

    def First_order_lag_filteringY(self):  # 一阶滞后滤波
        self.alpha = 0.5  # 设置滞后系数
        if self.data_Index_Y > 0:
            self.dataY[self.data_Index_Y] = self.alpha * self.dataY[self.data_Index_Y] + (1 - self.alpha) * self.dataY[
                self.data_Index_Y - 1]

    def First_order_lag_filteringZ(self):  # 一阶滞后滤波
        self.alpha = 0.5  # 设置滞后系数
        if self.data_Index_Z > 0:
            self.dataZ[self.data_Index_Z] = self.alpha * self.dataZ[self.data_Index_Z] + (1 - self.alpha) * self.dataZ[
                self.data_Index_Z - 1]

    def First_order_lag_filteringH(self):  # 一阶滞后滤波
        self.alpha = 0.5  # 设置滞后系数
        if self.data_Index_H > 0:
            self.dataH[self.data_Index_H] = self.alpha * self.dataH[self.data_Index_H] + (1 - self.alpha) * self.dataH[
                self.data_Index_H - 1]

    def First_order_lag_filteringC(self):  # 一阶滞后滤波
        self.alpha = 0.5  # 设置滞后系数
        if self.data_Index_C > 0:
            self.dataC[self.data_Index_C] = self.alpha * self.dataC[self.data_Index_C] + (1 - self.alpha) * self.dataC[
                self.data_Index_C - 1]

    def First_order_lag_filteringM(self):  # 一阶滞后滤波
        self.alpha = 0.5  # 设置滞后系数
        if self.data_Index_M > 0:
            self.dataM[self.data_Index_M] = self.alpha * self.dataM[self.data_Index_M] + (1 - self.alpha) * self.dataM[
                self.data_Index_M - 1]

    def logs_display(self):
        self.ui9.show()

    def logs_save(self):
        if self.Detection == "停止结束":
            self.Stop_receiving_time = datetime.datetime.now()
            time_str = self.Stop_receiving_time.strftime("%Y-%m-%d %H:%M:%S")
            item = QTableWidgetItem(time_str)
            self.ui9.tableWidget.setItem(self.row2, 3, item)
            self.ui9.tableWidget.update()
            print(self.Detection)
        else:
            self.Time_recording = time.time()
            date_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.Time_recording))
            item = QTableWidgetItem(date_time)
            self.ui9.tableWidget.setItem(self.row, self.col, item)
            if self.row > 0:
                self.ui9.tableWidget.setRowCount(self.ui9.tableWidget.rowCount() + 1)
                self.Time_recording = time.time()
                date_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.Time_recording))
                item = QTableWidgetItem(date_time)
                self.ui9.tableWidget.setItem(self.row, self.col, item)
            self.row += 1
        self.ui9.tableWidget.resizeColumnsToContents()
        self.ui9.tableWidget.resizeRowsToContents()

    def Form_clearing(self):
        if self.Detection == "正在运行":
            reply = QMessageBox.question(self.ui, '提示', '确定要清除吗？接受还在进行！！！',
                                         QMessageBox.Yes | QMessageBox.No,
                                         QMessageBox.No)
            if reply == QMessageBox.No:
                return
            self.Detection = "停止结束"
        self.ui9.tableWidget.clear()
        header_labels = ["开始时间", "接受数据保存位置", "发送数据保存位置", "波形图片保存位置", "结束时间", ]
        self.ui9.tableWidget.setHorizontalHeaderLabels(header_labels)
        self.ui9.tableWidget.resizeColumnsToContents()
        self.ui9.tableWidget.resizeRowsToContents()
        self.row = 0
        self.row2 = 0

    def edit_send_display(self):
        self.ui11.show()

    def edit_send_apply(self):
        self.text7 = self.ui11.lineEdit.text()
        self.text8 = self.ui11.lineEdit_2.text()
        if self.text8.isdigit():
            pass
        else:
            QMessageBox.warning(self.ui11, '警告', '发送数据次数必须为整数')
            return
        if self.ser is None:
            QMessageBox.warning(self.ui11, '警告', '串口未打开')
            return
        elif self.ser.is_open:
            if self.text7 == "" or int(self.text8) < 0:
                QMessageBox.warning(self.ui11, '警告', '发送数据不能为空且发送数据次数必须大于0')
            elif self.ui11.checkBox.isChecked():
                self.timer5 = QtCore.QTimer()
                self.timer5.timeout.connect(self.sendText)
                self.timer5.start(1000)  # 每1秒发送一次数据
                self.timer6 = QtCore.QTimer()
                self.timer6.timeout.connect(self.send_data)
                self.timer6.start(1000)  # 每1秒发送一次数据
            else:
                num = 1
                while num <= int(self.text8):
                    if self.ui11.checkBox.isChecked():
                        self.timer5 = QtCore.QTimer()
                        self.timer5.timeout.connect(self.sendText)
                        self.timer5.start(1000)  # 每1秒发送一次数据
                        self.timer6 = QtCore.QTimer()
                        self.timer6.timeout.connect(self.send_data)
                        self.timer6.start(1000)  # 每1秒发送一次数据
                    self.ui.plainTextEdit.setPlainText(f"{self.text7}")
                    self.send_data()
                    num += 1

    def sendText(self):
        self.ui.plainTextEdit.setPlainText(f"{self.text7}")

    def edit_send_checkBox_change(self):
        if self.ui11.checkBox.isChecked():
            pass
        else:
            if self.timer5 is None:
                pass
            else:
                self.timer5.stop()
            if self.timer6 is None:
                pass
            else:
                self.timer6.stop()

    def Acquisition_control(self):
        if self.ui.comboBox_7.currentText() == "自选时间":
            if self.ui.lineEdit_4.text() == "":
                QMessageBox.critical(self.ui, "警告", "请输入时间")
            else:
                text = self.ui.lineEdit_4.text()
                self.ui.textEdit_2.append(f"已自选接收时间{text}")
                if text.endswith("s") and text[:-1].isdigit():
                    self.Control_time_1 = int(text[:-1]) * 1000
                elif text.endswith("min") and text[:-3].isdigit():
                    self.Control_time_1 = int(text[:-3]) * 60000
                else:
                    QMessageBox.critical(self.ui, "警告", "请输入正确的格式！", QMessageBox.Ok)
        else:
            QMessageBox.critical(self.ui, "警告", "请先选择采样模式为自选时间并输入时间", QMessageBox.Ok)

    def Sampling_time_selection(self):
        text = self.ui.comboBox_7.currentText()
        if text.endswith("s"):
            text = text[0:text.find("s")]
            self.ui.textEdit_2.append(f"已选择接收时间{text}")
            self.Control_time_2 = int(text) * 1000
        else:
            pass

    def Processing_display(self):
        self.ui12.show()
        self.ui12.textEdit.append(f"已处理模拟量值：{self.data2}")

    def Processing_display_2(self):
        self.ui12.textEdit.append(f"已处理模拟量值：{self.data2}")

    def Set_display(self):
        if self.ui13.isVisible():
            self.ui13.textEdit.clear()
            self.ui13.textEdit.append("*******************************************")
        else:
            self.ui13.show()
            self.ui13.textEdit.clear()
            self.ui13.textEdit.append("*******************************************")
        if not all([self.text.strip(), self.text2.strip(), self.text3.strip(),
                    self.text4.strip(), self.text5.strip()]):
            self.ui13.textEdit.append(f"<font color='red'>当前串口参数未设置完整！！！</font>")
        else:
            self.ui13.textEdit.append(f"选定的串口为：<font color='green'>{self.text}</font>")
            self.ui13.textEdit.append(f"选定的波特率为：<font color='green'>{self.text2}</font>")
            self.ui13.textEdit.append(f"选定的数据位为：<font color='green'>{self.text3}</font>")
            self.ui13.textEdit.append(f"选定的停止位为：<font color='green'>{self.text4}</font>")
            self.ui13.textEdit.append(f"选定的校验位为：<font color='green'>{self.text5}</font>")
        if self.ser is None:
            self.ui13.textEdit.append(f"当前串口状态：<font color='red'>串口未打开</font>")
        elif self.ser.is_open:
            self.ui13.textEdit.append(f"当前串口状态：<font color='blue'>串口已打开</font>")
        else:
            self.ui13.textEdit.append(f"当前串口状态：<font color='red'>串口未打开</font>")
        self.ui13.textEdit.append("*******************************************")
        if self.ui.comboBox_7.currentText() != "自选时间":
            self.ui13.textEdit.append(
                f"当前采样时间设置为：<font color='green'>{self.ui.comboBox_7.currentText()}</font>")
        elif self.ui.lineEdit_4.text() != "":
            self.ui13.textEdit.append(
                f"当前采样时间设置为：<font color='green'>{self.ui.comboBox_7.currentText()}:{self.ui.lineEdit_4.text()}</font>")
        else:
            self.ui13.textEdit.append(f"当前采样时间设置为：<font color='red'>当前采样时间未设置完整</font>")
        self.ui13.textEdit.append("*******************************************")
        self.ui13.textEdit.append(
            f"当前全局滤波幅值设置为：<font color='green'>{self.ui.comboBox_6.currentText()}</font>")
        self.ui13.textEdit.append("*******************************************")
        self.ui13.textEdit.append(f"当前单一通道滤波幅值设置为：")
        self.ui13.textEdit.append(f"电压滤波方式：<font color='green'>{self.ui4.comboBox_6.currentText()}</font>")
        self.ui13.textEdit.append(f"电流滤波幅值：<font color='green'>{self.ui4.comboBox_7.currentText()}</font>")
        self.ui13.textEdit.append(f"温度滤波方式：<font color='green'>{self.ui4.comboBox_8.currentText()}</font>")
        self.ui13.textEdit.append(f"模块温度滤波方式：<font color='green'>{self.ui4.comboBox_9.currentText()}</font>")
        self.ui13.textEdit.append(f"输入信号滤波方式：<font color='green'>{self.ui4.comboBox_10.currentText()}</font>")
        self.ui13.textEdit.append(f"输出信号滤波方式：<font color='green'>{self.ui4.comboBox_11.currentText()}</font>")
        self.ui13.textEdit.append(f"最大幅值波动K值：<font color='green'>{self.Maximum_value_fluctuation_number}</font>")
        self.ui13.textEdit.append(f"中值滤波取值K值：<font color='green'>{self.median_filter_number}</font>")
        self.ui13.textEdit.append(f"算术平均滤波K值：<font color='green'>{self.average_filter_number}</font>")
        self.ui13.textEdit.append(f"去极值平均滤波K值：<font color='green'>{self.De_extreme_number}</font>")
        self.ui13.textEdit.append(f"滑动平均滤波K值：<font color='green'>{self.window_size}</font>")
        self.ui13.textEdit.append(f"一阶滞后滤波α值：<font color='green'>{self.alpha}</font>")
        self.ui13.textEdit.append("*******************************************")
        self.ui13.textEdit.append(
            f"电压报警设置：上限：<font color='green'>{self.max_value1}</font>下限：<font color='green'>{self.min_value1}</font>")
        self.ui13.textEdit.append(
            f"电流报警设置：上限：<font color='green'>{self.max_value2}</font>下限：<font color='green'>{self.min_value2}</font>")
        self.ui13.textEdit.append(
            f"模块温度报警设置：上限：<font color='green'>{self.max_value3}</font>下限：<font color='green'>{self.min_value3}</font>")
        self.ui13.textEdit.append(
            f"湿度报警设置：上限：<font color='green'>{self.max_value4}</font>下限：<font color='green'>{self.min_value4}</font>")
        self.ui13.textEdit.append(
            f"输入信号报警设置：上限：<font color='green'>{self.max_value5}</font>下限：<font color='green'>{self.min_value5}</font>")
        self.ui13.textEdit.append(
            f"输出信号报警设置：上限：<font color='green'>{self.max_value5}</font>下限：<font color='green'>{self.min_value5}</font>")
        self.ui13.textEdit.append("*******************************************")
        self.ui13.textEdit.append(f"开启模块指令:<font color='green'>{self.module_instruction1}</font>")
        self.ui13.textEdit.append(f"关闭模块指令:<font color='green'>{self.module_instruction2}</font>")
        self.ui13.textEdit.append("*******************************************")

    def Run_message_clearing(self):
        self.ui.textEdit_2.clear()

    def Set_display_2(self):
        self.ui13.textEdit.clear()
        self.Set_display()

    def Image_window_editing(self):
        self.ui14.show()

    def save_Image_window_editing(self):
        text = 0
        if self.ui14.lineEdit.text() != "":
            self.Window_name1 = self.ui14.lineEdit.text()
            self.ui2.label.setText(self.Window_name1)
            text = 1
        if self.ui14.lineEdit_2.text() != "":
            self.Window_name2 = self.ui14.lineEdit_2.text()
            self.ui2.label_2.setText(self.Window_name2)
            text = 1
        if self.ui14.lineEdit_3.text() != "":
            self.Window_name3 = self.ui14.lineEdit_3.text()
            self.ui2.label_3.setText(self.Window_name3)
            text = 1
        if self.ui14.lineEdit_4.text() != "":
            self.Window_name4 = self.ui14.lineEdit_4.text()
            self.ui2.label_4.setText(self.Window_name4)
            text = 1
        if self.ui14.lineEdit_5.text() != "":
            self.Window_name5 = self.ui14.lineEdit_5.text()
            self.ui2.label_5.setText(self.Window_name5)
            text = 1
        if self.ui14.lineEdit_6.text() != "":
            self.Window_name6 = self.ui14.lineEdit_6.text()
            self.ui2.label_6.setText(self.Window_name6)
            text = 1
        if text == 1:
            self.config5['Image_window_editing'] = {
                '电压': self.Window_name1,
                '电流': self.Window_name2,
                '模块温度': self.Window_name3,
                '湿度模块': self.Window_name4,
                '输入信号': self.Window_name5,
                '输出信号': self.Window_name6
            }
            self.config5.write(open('config5.ini', 'w'))
            self.ui.textEdit_2.append("图像窗口名称编辑保存成功！")
        else:
            self.ui.textEdit_2.append("图像窗口名称编辑保存失败！请编辑好再保存")

    def use_Image_window_editing(self):
        self.config5.read('config5.ini')
        if self.config5 and 'Image_window_editing' in self.config5:
            self.Window_name1 = self.config5['Image_window_editing']['电压']
            self.Window_name2 = self.config5['Image_window_editing']['电流']
            self.Window_name3 = self.config5['Image_window_editing']['模块温度']
            self.Window_name4 = self.config5['Image_window_editing']['湿度模块']
            self.Window_name5 = self.config5['Image_window_editing']['输入信号']
            self.Window_name6 = self.config5['Image_window_editing']['输出信号']
            self.ui2.label.setText(self.Window_name1)
            self.ui2.label_2.setText(self.Window_name2)
            self.ui2.label_6.setText(self.Window_name3)
            self.ui2.label_3.setText(self.Window_name4)
            self.ui2.label_5.setText(self.Window_name5)
            self.ui2.label_7.setText(self.Window_name6)

    def Open_module_instruction_ui(self):
        self.ui15.show()

    def save_module_instruction(self):
        text = 0
        if self.ui15.lineEdit.text() != "":
            self.module_instruction1 = self.ui15.lineEdit.text()
            text = 1
        if self.ui15.lineEdit_2.text() != "":
            self.module_instruction2 = self.ui15.lineEdit_2.text()
            text = 1
        if text == 1:
            self.config6['module_instruction'] = {
                '开启指令编辑': self.module_instruction1,
                '关闭指令编辑': self.module_instruction2,
            }
            self.config6.write(open('config6.ini', 'w'))
            self.ui.textEdit_2.append("模块开关指令保存成功！")
        else:
            self.ui.textEdit_2.append("模块开关指令保存失败！请编辑好再保存")

    def use_module_instruction(self):
        self.config6.read('config6.ini')
        if self.config6 and 'module_instruction' in self.config6:
            self.module_instruction1 = self.config6['module_instruction']['开启指令编辑']
            self.module_instruction2 = self.config6['module_instruction']['关闭指令编辑']
            self.ui15.lineEdit.setText(self.module_instruction1)
            self.ui15.lineEdit_2.setText(self.module_instruction2)

    def use_module_instruction2(self):
        if self.ui15.lineEdit.text() != "":
            self.module_instruction1 = self.ui15.lineEdit.text()
            self.ui.textEdit_2.append("模块开启指令应用成功！")
        if self.ui15.lineEdit_2.text() != "":
            self.module_instruction2 = self.ui15.lineEdit_2.text()
            self.ui.textEdit_2.append("模块关闭指令应用成功！")

    def Open_module(self):
        if self.ser is None:
            QMessageBox.information(self.ui, '提示', '请先连接串口！')
            return
        self.ui.plainTextEdit.insertPlainText(self.module_instruction1)
        self.send_data()

    def Close_module(self):
        if self.ser is None:
            QMessageBox.information(self.ui, '提示', '请先连接串口！')
            return
        self.ui.plainTextEdit.insertPlainText(self.module_instruction2)
        self.send_data()

    def Status_code_editing(self):
        self.ui16.show()

    def use_Status_code_editing(self):
        if self.ser is None:
            QMessageBox.information(self.ui, '提示', '请先连接串口！')
        elif self.ser.is_open and self.ui16.lineEdit.text() != "":
            self.Status_code = self.ui16.lineEdit.text()
            self.ui.plainTextEdit.insertPlainText(self.Status_code)
            self.Status_code_request = True
            self.send_data()
        else:
            QMessageBox.information(self.ui16, "提示", "请检查状态码是否编辑或者串口是否已经打开！", QMessageBox.Ok)

    def save_open_module_instruction(self):
        if self.ui15.lineEdit.text() != "":
            self.module_instruction1 = self.ui15.lineEdit.text()
            self.ui.textEdit_2.append("打开模块指令已保存")
            self.ui15.comboBox.addItem(self.module_instruction1)
            with open("open_module_instructions.txt", "a") as file:
                file.write(self.module_instruction1 + "\n")

    def save_close_module_instruction(self):
        if self.ui15.lineEdit_2.text() != "":
            self.module_instruction2 = self.ui15.lineEdit_2.text()
            self.ui.textEdit_2.append("关闭模块指令已保存")
            self.ui15.comboBox_2.addItem(self.module_instruction2)
            with open("close_module_instructions.txt", "a") as file:
                file.write(self.module_instruction2 + "\n")

    def load_open_module_instruction(self):
        if os.path.exists('open_module_instructions.txt'):
            with open("open_module_instructions.txt", "r") as file:
                instructions = file.readlines()
            for instruction in instructions:
                self.ui15.comboBox.addItem(instruction.strip())

    def load_close_module_instruction(self):
        if os.path.exists('close_module_instructions.txt'):
            with open("close_module_instructions.txt", "r") as file:
                instructions = file.readlines()
            for instruction in instructions:
                self.ui15.comboBox_2.addItem(instruction.strip())

    def Instruction_selection1(self):
        self.ui15.lineEdit.setText(self.ui15.comboBox.currentText())
        if self.ui15.lineEdit.text() == "请选择指令":
            self.ui15.lineEdit.setText("")

    def Instruction_selection2(self):
        self.ui15.lineEdit_2.setText(self.ui15.comboBox_2.currentText())
        if self.ui15.lineEdit_2.text() == "请选择指令":
            self.ui15.lineEdit_2.setText("")

    def open_module_instruction_delete(self):
        index = self.ui15.comboBox.currentIndex()
        if index != 0:
            self.ui15.comboBox.removeItem(index)
            with open("open_module_instructions.txt", "w") as f:
                f.write("")
            items = [self.ui15.comboBox.itemText(i) for i in range(self.ui15.comboBox.count()) if i != 0]
            with open('open_module_instructions.txt', 'w') as f:
                for item in items:
                    f.write(item + '\n')
            print("指令已删除。")

    def close_module_instruction_delete(self):
        index = self.ui15.comboBox_2.currentIndex()
        if index != 0:
            self.ui15.comboBox_2.removeItem(index)
            with open("close_module_instructions.txt", "w") as f:
                f.write("")
            items = [self.ui15.comboBox_2.itemText(i) for i in range(self.ui15.comboBox_2.count()) if i != 0]
            with open('close_module_instructions.txt', 'w') as f:
                for item in items:
                    f.write(item + '\n')
            print("指令已删除。")


if __name__ == "__main__":
    App = QApplication(sys.argv)
    stats = Stats()
    stats.ui.show()
    sys.exit(App.exec())
