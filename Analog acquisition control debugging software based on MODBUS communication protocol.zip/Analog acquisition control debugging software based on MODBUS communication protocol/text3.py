import crcmod.predefined
def parse_modbus_response(response):
    # 将十六进制字符串转换为字节列表
    address = response[0:2]
    print(address)
    response_bytes = bytes.fromhex(response)
    # 获取字节长度
    byte_count = response_bytes[2]
    # 计算寄存器数量
    register_count = byte_count // 2
    # 初始化寄存器列表
    registers = []
    # 解析每个寄存器的值
    for i in range(register_count):
        # 获取字节索引
        byte_index = 3 + i * 2
        # 获取高位字节和低位字节
        high_byte = response_bytes[byte_index]
        low_byte = response_bytes[byte_index + 1]
        # 计算寄存器值
        register_value = (high_byte << 8) + low_byte
        # 添加到寄存器列表
        registers.append(register_value)
    # 计算CRC值
    crc_fn = crcmod.predefined.mkPredefinedCrcFun('modbus')
    crc = crc_fn(response_bytes[:-2])
    # 将CRC值从响应数据中提取出来
    crc_bytes = response_bytes[-2:]
    crc_result = (crc_bytes[1] << 8) + crc_bytes[0]
    # 验证CRC值
    if crc == crc_result:
        print("校验通过")
    else:
        print("校验失败")
    return registers
# 示例使用
response = "010302000AB27E"
registers = parse_modbus_response(response)
for i, register_value in enumerate(registers):
    print(f"Register {i + 1}: {register_value}")


class ModbusReader:
    def __init__(self):
        self.ser = None

    def parse_modbus_response(self, response):
        # 将十六进制字符串转换为字节列表
        response_bytes = bytes.fromhex(response)
        # 获取字节长度
        byte_count = response_bytes[2]
        # 计算寄存器数量
        register_count = byte_count // 2
        # 初始化寄存器列表
        registers = []
        # 解析每个寄存器的值
        for i in range(register_count):
            # 获取字节索引
            byte_index = 3 + i * 2
            # 获取高位字节和低位字节
            high_byte = response_bytes[byte_index]
            low_byte = response_bytes[byte_index + 1]
            # 计算寄存器值
            register_value = (high_byte << 8) + low_byte
            # 添加到寄存器列表
            registers.append(register_value)
        # 计算CRC值
        crc_fn = crcmod.predefined.mkPredefinedCrcFun('modbus')
        crc = crc_fn(response_bytes[:-2])
        # 将CRC值从响应数据中提取出来
        crc_bytes = response_bytes[-2:]
        crc_result = (crc_bytes[1] << 8) + crc_bytes[0]
        # 验证CRC值
        if crc == crc_result:
            print("校验通过")
        else:
            print("校验失败")
        return registers

    def read_data(self):
        try:
            self.ser.timeout = 0.01
            # 从串口读取数据
            response = self.ser.readline(1024).decode().strip()
            print("接收到的响应报文:", response)
            # 处理响应报文
            registers = self.parse_modbus_response(response)
            for i, register_value in enumerate(registers):
                print(f"Register {i + 1}: {register_value}")
        except Exception as e:
            print("读取数据时发生错误:", str(e))