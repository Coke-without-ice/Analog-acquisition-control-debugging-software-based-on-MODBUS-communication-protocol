import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QFileDialog, QWidget, QApplication, QMessageBox
from PyQt5.QtCore import pyqtSignal, pyqtSlot


class SubWindow(QWidget):
    child_signal = pyqtSignal(str)  # 将信号对象设置为类属性

    def __init__(self):
        super(SubWindow, self).__init__()
        self.information1 = ""
        self.information2 = ""
        self.ui3 = uic.loadUi("save.ui")
        self.ui3.comboBox.currentIndexChanged.connect(self.on_combobox_changed)
        self.ui3.comboBox_2.currentIndexChanged.connect(self.on_combobox_2_changed)
        self.ui3.pushButton_2.clicked.connect(self.save_button)
        self.choice_1 = ""
        self.choice_2 = ""

    def on_combobox_changed(self):
        self.choice_2 = self.ui3.comboBox.currentText()
        print(self.choice_2)

    def on_combobox_2_changed(self):
        self.choice_1 = self.ui3.comboBox_2.currentText()
        print(self.choice_1)

    def save_button(self):
        if self.choice_1 == "" and self.choice_2 == "":
            QMessageBox.critical(self.ui3, "错误", "请选择需要保存的内容与类型！")
        elif (self.choice_1 == "串口接受到的数据" or self.choice_1 == "串口已发送的数据") and self.choice_2 == "":
            QMessageBox.critical(self.ui3, "错误", "请选择需要保存的类型！")
        elif self.choice_1 == "" and self.choice_2 == "保存为txt文件":
            QMessageBox.critical(self.ui3, "错误", "请选择需要保存的内容！")
        else:
            self.get_file_path()

    def get_file_path(self):
        save_operations = {
            ("串口接受到的数据", "保存为txt文件"): self.save_txt,
            ("串口已发送的数据", "保存为txt文件"): self.save_txt,
        }
        operation = save_operations.get((self.choice_1, self.choice_2))
        if operation:
            try:
                operation(self.information1 if self.choice_1 == "串口已发送的数据" else self.information2)
            except Exception as e:
                print("保存失败:", e)
        else:
            QMessageBox.critical(self.ui3, "错误", "保存方式暂不支持！")

    def save_txt(self, data):
        default_filename = 'default.txt'
        filepath, _ = QFileDialog.getSaveFileName(self, "文件保存", default_filename, 'txt(*.txt)')
        if filepath:
            try:
                with open(filepath, 'w') as file:
                    file.write(data)
                QMessageBox.information(self.ui3, "提示", "保存成功！")
                self.send_message(filepath)
            except IOError as e:
                QMessageBox.critical(self.ui3, "错误", "保存失败:", e)

    def send_message(self, message):
        print(message)
        self.child_signal.emit(message)  # 发送信号
        print("信号已发送")


class MainWindow(QWidget):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.child_window = SubWindow()
        self.child_window.child_signal.connect(self.handle_child_signal)

    def action_b(self, send_data, received_data):
        self.child_window.ui3.show()
        self.child_window.information1 = send_data
        self.child_window.information2 = received_data

    @pyqtSlot(str)
    def handle_child_signal(self, message):
        print("接收到信号:", message)
        self.child_window.ui3.close()

    def close_child_window_ui3(self):
        self.child_window.ui3.close()


if __name__ == "__main__":
    App = QApplication([])
    main_win = MainWindow()
    main_win.action_b("发送的数据", "接收的数据")
    sys.exit(App.exec_())
