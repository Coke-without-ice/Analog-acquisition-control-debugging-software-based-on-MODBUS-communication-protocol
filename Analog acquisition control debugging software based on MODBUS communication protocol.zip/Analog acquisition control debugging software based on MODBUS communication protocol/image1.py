import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout
from PyQt5 import uic
import numpy as np
import logging
import pyqtgraph as pg
from PyQt5.QtCore import Qt

class ImageWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowStaysOnTopHint)  # 设置窗口始终在顶层显示
        try:
            self.ui = uic.loadUi("image.ui")  # 加载用户界面
            central_widget = pg.LayoutWidget()
            self.setCentralWidget(central_widget)  # 设置LayoutWidget为主窗口的中心部件
            # 生成随机数据并进行可视化
            data = np.random.normal(size=10000)
            plot_widget = pg.PlotWidget()  # 创建绘图控件
            central_widget.addWidget(plot_widget, row=0, col=0)  # 将绘图控件添加到LayoutWidget中
            # 绘制随机数据曲线
            plot_widget.plot(data, pen=pg.mkPen(color='r', width=1))
            self.show()  # 显示用户界面
        except Exception as e:
            print(f"发生了错误: {str(e)}")
            logging.exception("发生了错误: %s", str(e))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    image_window = ImageWindow()
    sys.exit(app.exec_())

