#include "stm32f10x.h"                  // Device header
#include "delay.h"
#include "OLED.h"
#include  "dh11.h"
#include "Serial.h"
#include "Key.h"
#include "modbus.h"
#include "timer.h"

extern unsigned int rec_data[4];
uint8_t Temperature_and_humidity[9];
volatile uint8_t send_data_flag = 0;

int main()
{
  OLED_Init();
  Serial_Init();
  Key_Init();
  TIM2_Int_Init(7200-1,10-1);
  uint16_t key_sum;
  
  while(1)
  {
    key_sum = Key_GetNum();
    if(key_sum == 1)
    {
      if(send_data_flag == 0)
      {
        send_data_flag = 1;
      }
      else
      {
        send_data_flag = 0;
      }
    }
    if(send_data_flag == 1)
    {
      Modbus_Service();
      DHT11_REC_Data(); 
      OLED_ShowNum (1, 1, rec_data[2], 2); 
      OLED_ShowNum (2, 1, rec_data[0], 2); 	
      Delay_ms(500);
      Temperature_and_humidity[0] = 0x01;
      Temperature_and_humidity[1] = 0x03;
      Temperature_and_humidity[2] = 0x04;
      Temperature_and_humidity[3] = (rec_data[2] >> 8) & 0xFF;
      Temperature_and_humidity[4] = rec_data[2] & 0xFF;
      Temperature_and_humidity[5] = (rec_data[0] >> 8) & 0xFF;
      Temperature_and_humidity[6] = rec_data[0] & 0xFF;
//      Temperature_and_humidity[7] = 0xD5;
//      Temperature_and_humidity[8] = 0xCA;
//      Serial_SendArray(Temperature_and_humidity, 9);
    }
    else
    {
      OLED_Clear();
    }
  }
}

