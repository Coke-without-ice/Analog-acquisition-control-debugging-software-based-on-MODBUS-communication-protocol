#include "stm32f10x.h"                  // Device header


void crc_init(void)
{
    RCC->AHBENR |= RCC_AHBENR_CRCEN; // 使能CRC时钟
}



uint16_t calculate_crc(uint8_t *data, uint16_t length)
{
    CRC->CR = CRC_CR_RESET; // 复位CRC

    for (uint16_t i = 0; i < length; i++)
    {
        CRC->DR = data[i];
    }

    return CRC->DR;
}
