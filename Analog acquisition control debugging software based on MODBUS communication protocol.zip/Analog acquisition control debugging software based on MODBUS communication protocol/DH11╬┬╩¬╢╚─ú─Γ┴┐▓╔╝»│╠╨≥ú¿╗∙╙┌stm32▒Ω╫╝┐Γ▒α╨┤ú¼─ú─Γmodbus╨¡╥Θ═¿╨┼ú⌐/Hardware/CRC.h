#ifndef _CRC_H
#define _CRC_H

void crc_init(void);
uint16_t calculate_crc(uint8_t *data, uint16_t length);

#endif
