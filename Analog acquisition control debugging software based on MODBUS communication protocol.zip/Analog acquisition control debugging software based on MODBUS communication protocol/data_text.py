import os
import logging
from PySide2.QtWidgets import QVBoxLayout, QTextEdit, QMessageBox, QWidget, QApplication
from PySide2.QtUiTools import QUiLoader
from PyQt5.QtGui import QGuiApplication
from PyQt5.QtCore import Qt
QGuiApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
QGuiApplication.setAttribute(Qt.AA_UseHighDpiPixmaps)
QGuiApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)

class LogDialog(QWidget):
    def __init__(self, file_path, asin, *args, **kwargs):
        super().__init__(*args, **kwargs)
        loader = QUiLoader()
        self.ui = loader.load('DataLog.ui')
        self.asin = asin
        self.file_path = file_path
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("日志记录")
        self.resize(500, 400)
        layout = QVBoxLayout()
        text_edit = QTextEdit()
        text_edit.setText("")

        layout.addWidget(text_edit)
        self.setLayout(layout)

        # 读取日志展示出来
        if not os.path.exists(self.file_path):
            choice = QMessageBox.question(self, "提示", "日志不存在，是否创建新日志",
                                          QMessageBox.Yes | QMessageBox.No)
            if choice == QMessageBox.Yes:
                logging.basicConfig(filename=self.file_path, level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
            else:
                return

        # 读取日志
        with open(self.file_path, mode='r', encoding='utf-8') as f:
            content = f.read()
        # 展示日志
        text_edit.setText(content)


if __name__ == "__main__":
    app = QApplication([])
    dialog = LogDialog("C:\\Users\陈梦迪\Desktop\pythonProject1\\app.log", "your_asin")
    dialog.ui.show()
    app.exec_()


