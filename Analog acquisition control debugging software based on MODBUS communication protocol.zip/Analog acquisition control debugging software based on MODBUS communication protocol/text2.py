import crcmod.predefined

# 给定数据
data = ['0x4', '0x3', '0x18', '0x20']

# 将数据转换为字节列表
data_bytes = bytes([int(x, 16) for x in data])

# 计算CRC值
crc_fn = crcmod.predefined.mkPredefinedCrcFun('modbus')
crc = crc_fn(data_bytes)

# 提取实际的CRC校验位
crc_check = bytes([int('0xd5', 16), int('0xca', 16)])
crc_result = (crc_check[1] << 8) + crc_check[0]

# 验证CRC值
if crc == crc_result:
    print("CRC校验通过")
else:
    print("CRC校验失败")