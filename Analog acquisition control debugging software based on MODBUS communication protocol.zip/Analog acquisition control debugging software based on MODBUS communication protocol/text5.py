import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QLabel, QDialog, QLineEdit
from PyQt5.QtCore import pyqtSignal, Qt

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()

        self.button = QPushButton("Open Sub UI")
        self.label = QLabel("Data from Main UI")

        layout = QVBoxLayout()
        layout.addWidget(self.button)
        layout.addWidget(self.label)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

        self.button.clicked.connect(self.openSubUI)

    def openSubUI(self):
        self.sub_ui = SubWindow()
        self.sub_ui.data_signal.connect(self.receiveData)
        self.sub_ui.exec_()

    def receiveData(self, data):
        self.label.setText(data)


class SubWindow(QDialog):
    data_signal = pyqtSignal(str)

    def __init__(self):
        super(SubWindow, self).__init__()

        self.setWindowTitle('Sub UI')
        self.setGeometry(200, 200, 300, 100)

        self.send_button = QPushButton('Send')
        self.line_edit = QLineEdit()

        layout = QVBoxLayout()
        layout.addWidget(self.line_edit)
        layout.addWidget(self.send_button)

        self.setLayout(layout)

        self.send_button.clicked.connect(self.sendData)

    def sendData(self):
        data = self.line_edit.text()
        self.data_signal.emit(data)
        self.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())
