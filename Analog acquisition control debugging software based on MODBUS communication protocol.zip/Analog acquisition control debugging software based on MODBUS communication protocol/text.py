import crcmod.predefined

# 定义数据
data = [1, 3, 0, 0, 0, 1]

# 将数据转换为字节串
data_bytes = bytes(data)

# 计算CRC校验值
crc16 = crcmod.predefined.Crc('modbus')
crc16.update(data_bytes)
crc_value = crc16.crcValue.to_bytes(2, byteorder='little')

# 添加CRC校验值到数据末尾
data_with_crc = data_bytes + crc_value

# 打印结果
print("原始数据：", data)
print("数据的字节串形式：", data_bytes)
print("添加CRC校验位后的数据：", list(data_with_crc))