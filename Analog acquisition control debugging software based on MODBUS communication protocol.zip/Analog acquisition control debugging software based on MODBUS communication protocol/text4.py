from PyQt5.QtCore import pyqtSignal, QObject
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QPushButton

class ChildWindow(QDialog):
    child_signal = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        self.setLayout(layout)

        self.button = QPushButton("Send Message to Parent")
        self.button.clicked.connect(self.send_message)
        layout.addWidget(self.button)

    def send_message(self):
        message = "Hello from child window!"
        self.child_signal.emit(message)


if __name__ == '__main__':
    import sys
    from PyQt5.QtWidgets import QApplication
    app = QApplication(sys.argv)
    child_window = ChildWindow()
    child_window.show()
    sys.exit(app.exec_())